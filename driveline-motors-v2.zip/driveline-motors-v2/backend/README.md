# Driveline Motors API

Layered Express + PostgreSQL backend.

```
src/
  config/        env loading
  constants/     shared enums (vehicle types, service types, slots, booking status)
  db/            pg pool, schema.sql, migrate.js, seed.js
  validators/    Zod request schemas
  repositories/  raw SQL, one file per entity — the only layer that talks to Postgres
  services/      business rules (matching/ranking, slot-capacity booking logic)
  controllers/   thin req/res glue
  routes/        URL -> controller wiring, versioned under /v1
  middlewares/   asyncHandler, requestLogger, validate, errorHandler
  app.js         Express app factory (no listening — easy to import in tests)
server.js         entrypoint: verifies DB connection, then starts listening
```

## Scripts
- `npm run dev` — start with auto-reload
- `npm run migrate` — apply schema.sql (adds garage_vehicles, service_records, vehicle_health_logs)
- `npm run seed` — load sample dealer inventory + two sample garage vehicles (one healthy, one deliberately overdue, so alerts are visible immediately)
- `npm test` — run the full test suite (validators + alert engine), `node --test`

## A note on garage data and multi-tenancy

There's now a real account system (`users` table, bcrypt + JWT — see below), but
the garage/booking endpoints don't yet *enforce* ownership: `/garage/vehicles`
still returns every vehicle in the table to anyone who calls it, logged in or
guest, identified only loosely by the `ownerPhone` field someone typed into the
form. Login currently gates the frontend's screen (logged-out visitors see the
auth page instead of the app), but the API itself doesn't filter by `req.user`
yet. For a real multi-user deployment, the next step is: add an `owner_id`
foreign key to `garage_vehicles` pointing at `users.id`, have `POST
/garage/vehicles` set it from `req.user.id` (via the now-global `optionalAuthenticate`
middleware), and have `GET /garage/vehicles` filter by it — switching `authenticate`
(not `optionalAuthenticate`) onto the garage routes once guest-only access to
garage data is no longer wanted. That's a scoped, incremental change on top of
what's here now, not a redesign.

## API overview

All responses: `{ success, message, data, meta? }`. Errors: `{ success: false, message, details? }`.

| Method | Path                          | Notes                                   |
|--------|-------------------------------|------------------------------------------|
| GET    | /api/health                   | liveness check                            |
| GET    | /api/v1/vehicles              | filters: type, condition, fuel, brand, minPrice, maxPrice, search, sortBy, page, limit |
| GET    | /api/v1/vehicles/brands       | distinct brand list                       |
| GET    | /api/v1/vehicles/match        | budget/type/fuel -> ranked results with matchScore |
| GET    | /api/v1/vehicles/:id          |                                            |
| POST   | /api/v1/auth/register          | phone + password; 409 if that phone is already registered |
| POST   | /api/v1/auth/login             | returns `{ user, token }`; same error for unknown phone and wrong password |
| GET    | /api/v1/auth/me                | requires `Authorization: Bearer <token>` |
| GET    | /api/v1/bookings              | filters: status, date, page, limit        |
| POST   | /api/v1/bookings               | 409 if the date+slot is at capacity       |
| GET    | /api/v1/bookings/:id           |                                            |
| PATCH  | /api/v1/bookings/:id/cancel    | soft-cancel (keeps the record)            |
| DELETE | /api/v1/bookings/:id           | hard delete                               |
| GET    | /api/v1/garage/vehicles        | owned vehicles, each with computed alerts embedded |
| POST   | /api/v1/garage/vehicles        | 409 if the registration number already exists |
| GET    | /api/v1/garage/vehicles/:id    | includes alerts + service history + latest health log |
| PATCH  | /api/v1/garage/vehicles/:id    | partial update (odometer, expiry dates, etc.) |
| DELETE | /api/v1/garage/vehicles/:id    | removes the vehicle and its history (cascade) |
| GET    | /api/v1/garage/alerts          | flat list of every non-"ok" alert, across all vehicles |
| GET    | /api/v1/garage/vehicles/:id/service-records | service history for one vehicle |
| POST   | /api/v1/garage/vehicles/:id/service-records | logs a service; advances last-service date/odometer if newer |
| DELETE | /api/v1/garage/service-records/:recordId |                                |
| GET    | /api/v1/garage/vehicles/:id/health-logs | manual or Bluetooth-sourced readings |
| POST   | /api/v1/garage/vehicles/:id/health-logs | `source: 'manual' \| 'bluetooth'` |

### How the alert engine works (`src/services/alert.service.js`)

Insurance and RC fitness are date-based: `ok` while comfortably before the expiry
date, `warning` inside a 30-day window, `overdue` once past it. Service-due is
dual-tracked — both km since last service vs. `service_interval_km`, and time
since last service vs. `service_interval_months` — and the alert reports
whichever is more urgent, so a vehicle driven hard flags on distance and a
vehicle that mostly sits in a garage flags on time. Pure functions, unit-tested
in `test/alert.service.test.js` with a fixed `now` so the tests never go stale.

### Authentication (`src/services/auth.service.js`, `src/middlewares/auth.js`)

Phone number is the login identifier (the "username"), password is bcrypt-hashed
(10 salt rounds) before storage, and a successful login/register returns a JWT
(`JWT_SECRET`/`JWT_EXPIRES_IN` in `.env`). There are two auth middlewares:
`authenticate` rejects a request with no valid token (used on `GET /auth/me`),
while `optionalAuthenticate` — applied globally in `app.js` — attaches `req.user`
when a valid token is present but never blocks the request otherwise. That second
one is what makes "explore as guest" actually work on the frontend: every route
already tolerates a request with no `req.user`, so guest and logged-in traffic
share the exact same endpoints with no special-casing.

Verified against a live Postgres instance during development: filtering, pagination
meta, validation 400s, 404s, the slot-capacity 409, garage CRUD, duplicate-registration
409s, the alert computation against real seeded data, and the full auth flow
(register, duplicate-phone 409, login, wrong-password 400, `/me` with/without/garbage
token, guest requests with no token) all behave as documented above.
