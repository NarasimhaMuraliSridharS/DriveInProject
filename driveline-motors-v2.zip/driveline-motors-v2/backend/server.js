import { createApp } from './src/app.js';
import { env } from './src/config/env.js';
import { pool } from './src/db/pool.js';
import { logger } from './src/utils/logger.js';

async function start() {
  await pool.query('SELECT 1'); // fail fast if the database is unreachable
  logger.info('Database connection verified');

  const app = createApp();
  app.listen(env.port, () => {
    logger.info(`Driveline Motors API listening on port ${env.port} (${env.nodeEnv})`);
  });
}

start().catch((err) => {
  logger.error('Failed to start server', err);
  process.exitCode = 1;
});
