import { test } from 'node:test';
import assert from 'node:assert/strict';
import { registerSchema, loginSchema } from '../src/validators/auth.validators.js';

test('registerSchema accepts a well-formed signup', () => {
  const result = registerSchema.safeParse({ name: 'Asha Rao', phone: '9876543210', password: 'secret123' });
  assert.equal(result.success, true);
});

test('registerSchema rejects a short password', () => {
  const result = registerSchema.safeParse({ name: 'Asha Rao', phone: '9876543210', password: '123' });
  assert.equal(result.success, false);
});

test('registerSchema rejects a malformed phone number', () => {
  const result = registerSchema.safeParse({ name: 'Asha Rao', phone: 'not-a-phone', password: 'secret123' });
  assert.equal(result.success, false);
});

test('loginSchema requires both fields', () => {
  assert.equal(loginSchema.safeParse({ phone: '9876543210' }).success, false);
  assert.equal(loginSchema.safeParse({ password: 'secret123' }).success, false);
  assert.equal(loginSchema.safeParse({ phone: '9876543210', password: 'secret123' }).success, true);
});
