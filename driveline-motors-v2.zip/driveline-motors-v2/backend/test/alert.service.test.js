import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeDateAlert, computeServiceAlert, computeVehicleAlerts, worstLevel } from '../src/services/alert.service.js';

const NOW = new Date('2026-06-15T00:00:00.000Z');

test('computeDateAlert is "ok" when well before the due date', () => {
  const alert = computeDateAlert('insurance', 'Insurance', '2026-12-01', NOW);
  assert.equal(alert.level, 'ok');
});

test('computeDateAlert is "warning" within the warning window', () => {
  const alert = computeDateAlert('insurance', 'Insurance', '2026-06-30', NOW);
  assert.equal(alert.level, 'warning');
  assert.equal(alert.daysRemaining, 15);
});

test('computeDateAlert is "overdue" once the date has passed', () => {
  const alert = computeDateAlert('fitness', 'RC fitness', '2026-05-01', NOW);
  assert.equal(alert.level, 'overdue');
  assert.ok(alert.message.includes('expired'));
});

test('computeServiceAlert is "ok" when well under the km interval and far from the date interval', () => {
  const vehicle = {
    lastServiceDate: '2026-06-01', lastServiceOdometer: 10000, currentOdometer: 10500,
    serviceIntervalKm: 5000, serviceIntervalMonths: 6,
  };
  const alert = computeServiceAlert(vehicle, NOW);
  assert.equal(alert.level, 'ok');
});

test('computeServiceAlert is "overdue" once the km interval is exceeded, even if the date interval is not', () => {
  const vehicle = {
    lastServiceDate: '2026-06-01', lastServiceOdometer: 10000, currentOdometer: 16000,
    serviceIntervalKm: 5000, serviceIntervalMonths: 6,
  };
  const alert = computeServiceAlert(vehicle, NOW);
  assert.equal(alert.level, 'overdue');
  assert.ok(alert.kmRemaining < 0);
});

test('computeServiceAlert takes the more urgent of km-based and date-based due', () => {
  // Far under the km interval, but the date interval passed months ago.
  const vehicle = {
    lastServiceDate: '2025-01-01', lastServiceOdometer: 10000, currentOdometer: 10200,
    serviceIntervalKm: 5000, serviceIntervalMonths: 6,
  };
  const alert = computeServiceAlert(vehicle, NOW);
  assert.equal(alert.level, 'overdue');
});

test('computeServiceAlert handles a vehicle with no service history yet', () => {
  const vehicle = {
    lastServiceDate: null, lastServiceOdometer: null, currentOdometer: 1200,
    serviceIntervalKm: 5000, serviceIntervalMonths: 6,
  };
  const alert = computeServiceAlert(vehicle, NOW);
  assert.equal(alert.level, 'ok');
  assert.equal(alert.dueDate, null);
});

test('computeVehicleAlerts returns all three alert types', () => {
  const vehicle = {
    insuranceExpiry: '2026-12-01', fitnessExpiry: '2026-12-01',
    lastServiceDate: '2026-06-01', lastServiceOdometer: 10000, currentOdometer: 10200,
    serviceIntervalKm: 5000, serviceIntervalMonths: 6,
  };
  const alerts = computeVehicleAlerts(vehicle, NOW);
  assert.equal(alerts.length, 3);
  assert.deepEqual(alerts.map((a) => a.type), ['insurance', 'fitness', 'service']);
});

test('worstLevel picks overdue over warning over ok', () => {
  assert.equal(worstLevel([{ level: 'ok' }, { level: 'warning' }]), 'warning');
  assert.equal(worstLevel([{ level: 'warning' }, { level: 'overdue' }, { level: 'ok' }]), 'overdue');
  assert.equal(worstLevel([{ level: 'ok' }]), 'ok');
});
