import { test } from 'node:test';
import assert from 'node:assert/strict';
import { listVehiclesQuerySchema, matchVehiclesQuerySchema } from '../src/validators/vehicle.validators.js';

test('listVehiclesQuerySchema accepts an empty query and defaults nothing destructively', () => {
  const result = listVehiclesQuerySchema.safeParse({});
  assert.equal(result.success, true);
});

test('listVehiclesQuerySchema coerces numeric strings from query params', () => {
  const result = listVehiclesQuerySchema.safeParse({ maxPrice: '500000', page: '2' });
  assert.equal(result.success, true);
  assert.equal(result.data.maxPrice, 500000);
  assert.equal(result.data.page, 2);
});

test('listVehiclesQuerySchema rejects an unknown vehicle type', () => {
  const result = listVehiclesQuerySchema.safeParse({ type: 'truck' });
  assert.equal(result.success, false);
});

test('matchVehiclesQuerySchema rejects a non-positive budget', () => {
  const result = matchVehiclesQuerySchema.safeParse({ budget: '-100' });
  assert.equal(result.success, false);
});
