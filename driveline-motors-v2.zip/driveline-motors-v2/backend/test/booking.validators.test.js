import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createBookingSchema } from '../src/validators/booking.validators.js';

function tomorrow() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

const validPayload = {
  name: 'Asha Rao',
  phone: '9876543210',
  serviceType: 'Oil change',
  date: tomorrow(),
  slot: '9:00 - 11:00 AM',
};

test('createBookingSchema accepts a well-formed booking', () => {
  const result = createBookingSchema.safeParse(validPayload);
  assert.equal(result.success, true);
});

test('createBookingSchema rejects a booking dated in the past', () => {
  const result = createBookingSchema.safeParse({ ...validPayload, date: '2020-01-01' });
  assert.equal(result.success, false);
});

test('createBookingSchema rejects an unknown service type', () => {
  const result = createBookingSchema.safeParse({ ...validPayload, serviceType: 'Engine swap' });
  assert.equal(result.success, false);
});

test('createBookingSchema rejects a malformed phone number', () => {
  const result = createBookingSchema.safeParse({ ...validPayload, phone: 'call-me-maybe' });
  assert.equal(result.success, false);
});
