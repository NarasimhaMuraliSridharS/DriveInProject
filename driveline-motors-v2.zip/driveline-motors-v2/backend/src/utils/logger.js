// Minimal leveled logger. Swap this out for pino/winston later without
// touching any of the call sites, since they only ever import `logger`.
function timestamp() {
  return new Date().toISOString();
}

function make(level) {
  const consoleMethod = level === 'debug' ? 'log' : level;
  return (...args) => {
    console[consoleMethod](`[${timestamp()}] [${level.toUpperCase()}]`, ...args);
  };
}

export const logger = {
  error: make('error'),
  warn: make('warn'),
  info: make('info'),
  debug: make('debug'),
};
