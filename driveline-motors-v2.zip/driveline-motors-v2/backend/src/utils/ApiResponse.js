// Every successful response goes through here so clients can always
// rely on the same envelope: { success, message, data, meta? }.
export function sendSuccess(res, { data = null, message = 'Success', statusCode = 200, meta } = {}) {
  const body = { success: true, message, data };
  if (meta) body.meta = meta;
  return res.status(statusCode).json(body);
}
