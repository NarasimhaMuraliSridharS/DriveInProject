// Central place for every enum-like value shared across layers.
// Keeping these in one file means validators, services and the DB schema
// can never quietly drift apart from each other.

export const VEHICLE_TYPES = ['car', 'bike'];
export const CONDITIONS = ['new', 'used'];
export const FUEL_TYPES = ['Petrol', 'Diesel', 'Electric', 'CNG'];

export const SERVICE_TYPES = [
  'General service',
  'Oil change',
  'Brake inspection',
  'Battery check',
  'Full service',
  'Bike tuning',
  'Denting & painting',
];

export const TIME_SLOTS = [
  '9:00 - 11:00 AM',
  '11:00 AM - 1:00 PM',
  '1:00 - 3:00 PM',
  '3:00 - 5:00 PM',
  '5:00 - 7:00 PM',
];

export const BOOKING_STATUS = {
  REQUESTED: 'requested',
  CONFIRMED: 'confirmed',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
};

export const BOOKING_STATUSES = Object.values(BOOKING_STATUS);

// Business rule: how many service bookings a single date+slot can hold
// before it's considered full. Lives here, not scattered in SQL or UI.
export const MAX_BOOKINGS_PER_SLOT = 4;

export const DEFAULT_PAGE_SIZE = 12;
export const MAX_PAGE_SIZE = 50;

// --- Garage: owned-vehicle tracking (insurance, RC fitness, service, health) ---

export const ALERT_LEVEL = {
  OK: 'ok',
  WARNING: 'warning',
  OVERDUE: 'overdue',
};

export const ALERT_TYPE = {
  INSURANCE: 'insurance',
  FITNESS: 'fitness',
  SERVICE: 'service',
};

// A date-based alert (insurance/fitness) turns 'warning' inside this window.
export const ALERT_WARNING_DAYS = 30;
// A service-due alert turns 'warning' inside this many km of the next due distance.
export const ALERT_WARNING_KM = 500;

export const DEFAULT_SERVICE_INTERVAL_KM = 5000;
export const DEFAULT_SERVICE_INTERVAL_MONTHS = 6;

export const HEALTH_LOG_SOURCES = ['manual', 'bluetooth'];
