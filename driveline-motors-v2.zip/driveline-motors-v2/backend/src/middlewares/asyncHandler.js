// Wrap async route handlers so a rejected promise reaches the central
// error handler instead of crashing the process or hanging the request.
export const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};
