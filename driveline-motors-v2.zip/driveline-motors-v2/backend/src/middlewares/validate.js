import { ApiError } from '../utils/ApiError.js';

// Generic Zod-schema validation middleware. Pass a schema and which part
// of the request it validates ('body' | 'query' | 'params'); on success
// the parsed (and coerced/defaulted) value replaces the raw input so
// controllers always work with clean, typed data.
export function validate(schema, source = 'body') {
  return (req, res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      return next(ApiError.badRequest('Validation failed', result.error.flatten()));
    }
    req[source] = result.data;
    next();
  };
}
