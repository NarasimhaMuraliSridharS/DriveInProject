import { authService } from '../services/auth.service.js';
import { ApiError } from '../utils/ApiError.js';

function extractToken(req) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  return scheme === 'Bearer' && token ? token : null;
}

// Rejects the request if there's no valid token. Use on routes that must
// know who the caller is.
export function authenticate(req, res, next) {
  const token = extractToken(req);
  if (!token) return next(new ApiError(401, 'Authentication required'));

  try {
    const payload = authService.verifyToken(token);
    req.user = { id: payload.sub, phone: payload.phone };
    next();
  } catch {
    next(new ApiError(401, 'Invalid or expired session'));
  }
}

// Attaches req.user when a valid token is present, but never blocks the
// request otherwise - this is what lets "explore as guest" actually work:
// the same endpoints serve guests and logged-in users alike.
export function optionalAuthenticate(req, res, next) {
  const token = extractToken(req);
  if (!token) return next();

  try {
    const payload = authService.verifyToken(token);
    req.user = { id: payload.sub, phone: payload.phone };
  } catch {
    // An expired/garbled token on an optional route is treated as "no
    // token" rather than an error - the request just proceeds as a guest.
  }
  next();
}
