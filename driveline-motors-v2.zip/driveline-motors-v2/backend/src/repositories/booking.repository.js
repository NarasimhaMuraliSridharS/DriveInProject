import { pool } from '../db/pool.js';

export const bookingRepository = {
  async findMany({ status, date }, { limit, offset }) {
    const clauses = [];
    const params = [];
    if (status) {
      params.push(status);
      clauses.push(`status = $${params.length}`);
    }
    if (date) {
      params.push(date);
      clauses.push(`date = $${params.length}`);
    }
    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';

    const dataParams = [...params, limit, offset];
    const dataSql = `SELECT * FROM bookings ${where} ORDER BY created_at DESC LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`;
    const countSql = `SELECT COUNT(*)::int AS total FROM bookings ${where}`;

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataSql, dataParams),
      pool.query(countSql, params),
    ]);

    return { rows: dataResult.rows, total: countResult.rows[0].total };
  },

  // Counts active (non-cancelled) bookings for a date+slot. Called inside
  // a transaction that already holds an advisory lock on that slot, so
  // this read-then-decide is safe from double-booking races.
  async countForSlot(date, slot, client = pool) {
    const { rows } = await client.query(
      `SELECT COUNT(*)::int AS total FROM bookings WHERE date = $1 AND slot = $2 AND status != 'cancelled'`,
      [date, slot]
    );
    return rows[0].total;
  },

  async findById(id) {
    const { rows } = await pool.query('SELECT * FROM bookings WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create(booking, client = pool) {
    const { id, name, phone, vehicleId, vehicleLabel, serviceType, date, slot, notes, status } = booking;
    const { rows } = await client.query(
      `INSERT INTO bookings (id, name, phone, vehicle_id, vehicle_label, service_type, date, slot, notes, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [id, name, phone, vehicleId || null, vehicleLabel || null, serviceType, date, slot, notes || null, status]
    );
    return rows[0];
  },

  async updateStatus(id, status) {
    const { rows } = await pool.query('UPDATE bookings SET status = $1 WHERE id = $2 RETURNING *', [status, id]);
    return rows[0] || null;
  },

  async remove(id) {
    const { rowCount } = await pool.query('DELETE FROM bookings WHERE id = $1', [id]);
    return rowCount > 0;
  },

  // Small transaction helper so the service layer never has to touch a
  // raw pg client directly - it just passes a callback.
  async withTransaction(fn) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },
};
