import { pool } from '../db/pool.js';

export const userRepository = {
  async findByPhone(phone) {
    const { rows } = await pool.query('SELECT * FROM users WHERE phone = $1', [phone]);
    return rows[0] || null;
  },

  async findById(id) {
    const { rows } = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async create({ id, name, phone, passwordHash }) {
    const { rows } = await pool.query(
      'INSERT INTO users (id, name, phone, password_hash) VALUES ($1,$2,$3,$4) RETURNING *',
      [id, name, phone, passwordHash]
    );
    return rows[0];
  },
};
