import { pool } from '../db/pool.js';

export const healthLogRepository = {
  async findByVehicle(garageVehicleId, { limit = 50 } = {}) {
    const { rows } = await pool.query(
      'SELECT * FROM vehicle_health_logs WHERE garage_vehicle_id = $1 ORDER BY recorded_at DESC LIMIT $2',
      [garageVehicleId, limit]
    );
    return rows;
  },

  async findLatest(garageVehicleId) {
    const { rows } = await pool.query(
      'SELECT * FROM vehicle_health_logs WHERE garage_vehicle_id = $1 ORDER BY recorded_at DESC LIMIT 1',
      [garageVehicleId]
    );
    return rows[0] || null;
  },

  async create(log) {
    const {
      id, garageVehicleId, source, batteryVoltage, fuelLevelPercent,
      odometer, engineTempC, dtcCodes, rawPayload,
    } = log;
    const { rows } = await pool.query(
      `INSERT INTO vehicle_health_logs
         (id, garage_vehicle_id, source, battery_voltage, fuel_level_percent, odometer, engine_temp_c, dtc_codes, raw_payload)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [
        id, garageVehicleId, source, batteryVoltage ?? null, fuelLevelPercent ?? null,
        odometer ?? null, engineTempC ?? null, dtcCodes || null,
        rawPayload != null ? JSON.stringify(rawPayload) : null,
      ]
    );
    return rows[0];
  },
};
