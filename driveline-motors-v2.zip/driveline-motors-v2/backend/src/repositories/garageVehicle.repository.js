import { pool } from '../db/pool.js';

function toRow(v) {
  return [
    v.id, v.ownerName, v.ownerPhone, v.type, v.brand, v.model, v.registrationNumber,
    v.purchaseDate || null, v.insuranceExpiry, v.fitnessExpiry,
    v.currentOdometer ?? 0, v.serviceIntervalKm, v.serviceIntervalMonths,
  ];
}

export const garageVehicleRepository = {
  async findMany({ ownerPhone } = {}) {
    if (ownerPhone) {
      const { rows } = await pool.query(
        'SELECT * FROM garage_vehicles WHERE owner_phone = $1 ORDER BY created_at DESC',
        [ownerPhone]
      );
      return rows;
    }
    const { rows } = await pool.query('SELECT * FROM garage_vehicles ORDER BY created_at DESC');
    return rows;
  },

  async findById(id) {
    const { rows } = await pool.query('SELECT * FROM garage_vehicles WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async findByRegistration(registrationNumber) {
    const { rows } = await pool.query(
      'SELECT * FROM garage_vehicles WHERE registration_number = $1',
      [registrationNumber]
    );
    return rows[0] || null;
  },

  async create(v) {
    const { rows } = await pool.query(
      `INSERT INTO garage_vehicles
         (id, owner_name, owner_phone, type, brand, model, registration_number,
          purchase_date, insurance_expiry, fitness_expiry, current_odometer,
          service_interval_km, service_interval_months)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,
               COALESCE($12, 5000), COALESCE($13, 6))
       RETURNING *`,
      toRow(v)
    );
    return rows[0];
  },

  // Builds `SET col = $n` only for keys actually present in `fields`, so a
  // partial update never clobbers columns the caller didn't mention.
  async update(id, fields) {
    const columnByKey = {
      ownerName: 'owner_name',
      ownerPhone: 'owner_phone',
      type: 'type',
      brand: 'brand',
      model: 'model',
      registrationNumber: 'registration_number',
      purchaseDate: 'purchase_date',
      insuranceExpiry: 'insurance_expiry',
      fitnessExpiry: 'fitness_expiry',
      currentOdometer: 'current_odometer',
      serviceIntervalKm: 'service_interval_km',
      serviceIntervalMonths: 'service_interval_months',
      lastServiceDate: 'last_service_date',
      lastServiceOdometer: 'last_service_odometer',
    };

    const sets = [];
    const params = [];
    for (const [key, column] of Object.entries(columnByKey)) {
      if (fields[key] !== undefined) {
        params.push(fields[key]);
        sets.push(`${column} = $${params.length}`);
      }
    }
    if (sets.length === 0) return this.findById(id);

    params.push(id);
    const { rows } = await pool.query(
      `UPDATE garage_vehicles SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`,
      params
    );
    return rows[0] || null;
  },

  async remove(id) {
    const { rowCount } = await pool.query('DELETE FROM garage_vehicles WHERE id = $1', [id]);
    return rowCount > 0;
  },
};
