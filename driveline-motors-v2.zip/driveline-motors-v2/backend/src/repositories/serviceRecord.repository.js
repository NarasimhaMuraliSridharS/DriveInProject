import { pool } from '../db/pool.js';

export const serviceRecordRepository = {
  async findByVehicle(garageVehicleId) {
    const { rows } = await pool.query(
      'SELECT * FROM service_records WHERE garage_vehicle_id = $1 ORDER BY service_date DESC, created_at DESC',
      [garageVehicleId]
    );
    return rows;
  },

  async create(record, client = pool) {
    const { id, garageVehicleId, serviceDate, odometer, serviceType, cost, notes } = record;
    const { rows } = await client.query(
      `INSERT INTO service_records (id, garage_vehicle_id, service_date, odometer, service_type, cost, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [id, garageVehicleId, serviceDate, odometer, serviceType, cost ?? null, notes || null]
    );
    return rows[0];
  },

  async remove(id) {
    const { rowCount } = await pool.query('DELETE FROM service_records WHERE id = $1', [id]);
    return rowCount > 0;
  },

  async withTransaction(fn) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  },
};
