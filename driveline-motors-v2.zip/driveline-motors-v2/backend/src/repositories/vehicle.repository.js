import { pool } from '../db/pool.js';

// This is the ONLY file in the app that knows SQL for vehicles.
// Services never see a query string; they call these named methods.

const SORTS = {
  price_asc: 'price ASC',
  price_desc: 'price DESC',
  year_desc: 'year DESC',
  newest: 'created_at DESC',
};

function buildWhere(filters) {
  const clauses = [];
  const params = [];

  if (filters.type && filters.type !== 'all') {
    params.push(filters.type);
    clauses.push(`type = $${params.length}`);
  }
  if (filters.condition && filters.condition !== 'all') {
    params.push(filters.condition);
    clauses.push(`condition = $${params.length}`);
  }
  if (filters.fuel && filters.fuel !== 'all') {
    params.push(filters.fuel);
    clauses.push(`fuel = $${params.length}`);
  }
  if (filters.brand && filters.brand !== 'all') {
    params.push(filters.brand);
    clauses.push(`brand ILIKE $${params.length}`);
  }
  if (filters.minPrice != null) {
    params.push(filters.minPrice);
    clauses.push(`price >= $${params.length}`);
  }
  if (filters.maxPrice != null) {
    params.push(filters.maxPrice);
    clauses.push(`price <= $${params.length}`);
  }
  if (filters.search) {
    params.push(`%${filters.search}%`);
    clauses.push(`(brand ILIKE $${params.length} OR model ILIKE $${params.length})`);
  }

  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  return { where, params };
}

export const vehicleRepository = {
  async findMany(filters, { limit, offset }) {
    const { where, params } = buildWhere(filters);
    const orderBy = SORTS[filters.sortBy] || SORTS.price_asc;

    const dataParams = [...params, limit, offset];
    const dataSql = `SELECT * FROM vehicles ${where} ORDER BY ${orderBy} LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`;
    const countSql = `SELECT COUNT(*)::int AS total FROM vehicles ${where}`;

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataSql, dataParams),
      pool.query(countSql, params),
    ]);

    return { rows: dataResult.rows, total: countResult.rows[0].total };
  },

  // Unpaginated fetch used internally by the matching algorithm, which
  // needs to score the whole candidate set before ranking it.
  async findAll(filters = {}) {
    const { where, params } = buildWhere(filters);
    const { rows } = await pool.query(`SELECT * FROM vehicles ${where} ORDER BY price ASC`, params);
    return rows;
  },

  async findById(id) {
    const { rows } = await pool.query('SELECT * FROM vehicles WHERE id = $1', [id]);
    return rows[0] || null;
  },

  async listBrands() {
    const { rows } = await pool.query('SELECT DISTINCT brand FROM vehicles ORDER BY brand ASC');
    return rows.map((r) => r.brand);
  },
};
