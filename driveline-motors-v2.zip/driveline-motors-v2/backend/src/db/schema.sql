-- Registered accounts. Phone is the login identifier (this app's "username").
-- Guests never get a row here - guest mode is purely a client-side choice to
-- skip login, not an anonymous account.
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  phone         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vehicles (
  id            TEXT PRIMARY KEY,
  type          TEXT NOT NULL CHECK (type IN ('car', 'bike')),
  condition     TEXT NOT NULL CHECK (condition IN ('new', 'used')),
  brand         TEXT NOT NULL,
  model         TEXT NOT NULL,
  price         NUMERIC NOT NULL CHECK (price >= 0),
  fuel          TEXT NOT NULL,
  year          INTEGER NOT NULL,
  body          TEXT NOT NULL,
  km            INTEGER,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vehicles_type ON vehicles (type);
CREATE INDEX IF NOT EXISTS idx_vehicles_brand ON vehicles (brand);
CREATE INDEX IF NOT EXISTS idx_vehicles_price ON vehicles (price);

CREATE TABLE IF NOT EXISTS bookings (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  phone         TEXT NOT NULL,
  vehicle_id    TEXT REFERENCES vehicles(id) ON DELETE SET NULL,
  vehicle_label TEXT,
  service_type  TEXT NOT NULL,
  date          DATE NOT NULL,
  slot          TEXT NOT NULL,
  notes         TEXT,
  status        TEXT NOT NULL DEFAULT 'requested'
                CHECK (status IN ('requested', 'confirmed', 'completed', 'cancelled')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bookings_date_slot ON bookings (date, slot);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings (status);

-- Garage: vehicles a customer actually owns (distinct from the dealer's
-- `vehicles` sale inventory above). This is what insurance/fitness/service
-- alerts and health logs are tracked against.
CREATE TABLE IF NOT EXISTS garage_vehicles (
  id                      TEXT PRIMARY KEY,
  owner_name              TEXT NOT NULL,
  owner_phone             TEXT NOT NULL,
  type                    TEXT NOT NULL CHECK (type IN ('car', 'bike')),
  brand                   TEXT NOT NULL,
  model                   TEXT NOT NULL,
  registration_number     TEXT NOT NULL UNIQUE,
  purchase_date           DATE,
  insurance_expiry        DATE NOT NULL,
  fitness_expiry          DATE NOT NULL,
  last_service_date       DATE,
  last_service_odometer   INTEGER,
  current_odometer        INTEGER NOT NULL DEFAULT 0,
  service_interval_km     INTEGER NOT NULL DEFAULT 5000,
  service_interval_months INTEGER NOT NULL DEFAULT 6,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_garage_vehicles_owner_phone ON garage_vehicles (owner_phone);

CREATE TABLE IF NOT EXISTS service_records (
  id                TEXT PRIMARY KEY,
  garage_vehicle_id TEXT NOT NULL REFERENCES garage_vehicles(id) ON DELETE CASCADE,
  service_date      DATE NOT NULL,
  odometer          INTEGER NOT NULL,
  service_type      TEXT NOT NULL,
  cost              NUMERIC,
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_service_records_vehicle ON service_records (garage_vehicle_id, service_date DESC);

-- Health readings for a garage vehicle: either typed in by hand, or
-- streamed from a Bluetooth-connected OBD adapter (source distinguishes
-- the two; raw_payload keeps whatever the adapter actually sent so it
-- can be re-parsed later without re-connecting to the device).
CREATE TABLE IF NOT EXISTS vehicle_health_logs (
  id                  TEXT PRIMARY KEY,
  garage_vehicle_id   TEXT NOT NULL REFERENCES garage_vehicles(id) ON DELETE CASCADE,
  source              TEXT NOT NULL CHECK (source IN ('manual', 'bluetooth')),
  battery_voltage     NUMERIC,
  fuel_level_percent  NUMERIC,
  odometer            INTEGER,
  engine_temp_c       NUMERIC,
  dtc_codes           TEXT,
  raw_payload         JSONB,
  recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_health_logs_vehicle ON vehicle_health_logs (garage_vehicle_id, recorded_at DESC);
