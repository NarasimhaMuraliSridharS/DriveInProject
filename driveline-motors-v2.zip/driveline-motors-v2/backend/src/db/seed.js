import { pool } from './pool.js';
import { logger } from '../utils/logger.js';

const VEHICLES = [
  { id: 'c1', type: 'car', condition: 'new', brand: 'Maruti Suzuki', model: 'Swift', price: 650000, fuel: 'Petrol', year: 2026, body: 'Hatchback', km: null },
  { id: 'c2', type: 'car', condition: 'new', brand: 'Hyundai', model: 'Creta', price: 1120000, fuel: 'Petrol', year: 2026, body: 'SUV', km: null },
  { id: 'c3', type: 'car', condition: 'new', brand: 'Tata', model: 'Nexon EV', price: 1450000, fuel: 'Electric', year: 2026, body: 'SUV', km: null },
  { id: 'c4', type: 'car', condition: 'new', brand: 'Honda', model: 'City', price: 1200000, fuel: 'Petrol', year: 2026, body: 'Sedan', km: null },
  { id: 'c5', type: 'car', condition: 'used', brand: 'Maruti Suzuki', model: 'Baleno', price: 580000, fuel: 'Petrol', year: 2021, body: 'Hatchback', km: 32000 },
  { id: 'c6', type: 'car', condition: 'used', brand: 'Hyundai', model: 'i20', price: 490000, fuel: 'Petrol', year: 2019, body: 'Hatchback', km: 45000 },
  { id: 'c7', type: 'car', condition: 'used', brand: 'Toyota', model: 'Innova', price: 950000, fuel: 'Diesel', year: 2018, body: 'MPV', km: 60000 },
  { id: 'b1', type: 'bike', condition: 'new', brand: 'Royal Enfield', model: 'Classic 350', price: 205000, fuel: 'Petrol', year: 2026, body: 'Cruiser', km: null },
  { id: 'b2', type: 'bike', condition: 'new', brand: 'TVS', model: 'Jupiter', price: 85000, fuel: 'Petrol', year: 2026, body: 'Scooter', km: null },
  { id: 'b3', type: 'bike', condition: 'new', brand: 'Ola', model: 'S1 Pro', price: 130000, fuel: 'Electric', year: 2026, body: 'Scooter', km: null },
  { id: 'b4', type: 'bike', condition: 'used', brand: 'Honda', model: 'Activa', price: 58000, fuel: 'Petrol', year: 2020, body: 'Scooter', km: 18000 },
  { id: 'b5', type: 'bike', condition: 'used', brand: 'Bajaj', model: 'Pulsar 150', price: 72000, fuel: 'Petrol', year: 2019, body: 'Motorcycle', km: 25000 },
];

async function seed() {
  for (const v of VEHICLES) {
    await pool.query(
      `INSERT INTO vehicles (id, type, condition, brand, model, price, fuel, year, body, km)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (id) DO UPDATE SET
         type = EXCLUDED.type, condition = EXCLUDED.condition, brand = EXCLUDED.brand,
         model = EXCLUDED.model, price = EXCLUDED.price, fuel = EXCLUDED.fuel,
         year = EXCLUDED.year, body = EXCLUDED.body, km = EXCLUDED.km`,
      [v.id, v.type, v.condition, v.brand, v.model, v.price, v.fuel, v.year, v.body, v.km]
    );
  }
  logger.info(`Seeded ${VEHICLES.length} vehicles`);
  await seedGarage();
  await pool.end();
}

// A couple of sample owned vehicles so the Garage page has something to
// show right after setup - one with a healthy status, one deliberately
// overdue so the alert levels are visible without manual data entry.
async function seedGarage() {
  const today = new Date();
  const inDays = (n) => new Date(today.getTime() + n * 86400000).toISOString().slice(0, 10);

  const GARAGE_VEHICLES = [
    {
      id: 'gv1', ownerName: 'Demo Owner', ownerPhone: '9876500001', type: 'car',
      brand: 'Hyundai', model: 'Creta', registrationNumber: 'TN09AB1234',
      purchaseDate: '2023-03-15', insuranceExpiry: inDays(90), fitnessExpiry: inDays(400),
      lastServiceDate: inDays(-40), lastServiceOdometer: 18000, currentOdometer: 18600,
      serviceIntervalKm: 5000, serviceIntervalMonths: 6,
    },
    {
      id: 'gv2', ownerName: 'Demo Owner', ownerPhone: '9876500001', type: 'bike',
      brand: 'Royal Enfield', model: 'Classic 350', registrationNumber: 'TN09CD5678',
      purchaseDate: '2022-01-10', insuranceExpiry: inDays(15), fitnessExpiry: inDays(-5),
      lastServiceDate: inDays(-200), lastServiceOdometer: 9000, currentOdometer: 14800,
      serviceIntervalKm: 3000, serviceIntervalMonths: 4,
    },
  ];

  for (const v of GARAGE_VEHICLES) {
    await pool.query(
      `INSERT INTO garage_vehicles
         (id, owner_name, owner_phone, type, brand, model, registration_number,
          purchase_date, insurance_expiry, fitness_expiry, last_service_date,
          last_service_odometer, current_odometer, service_interval_km, service_interval_months)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       ON CONFLICT (registration_number) DO UPDATE SET
         insurance_expiry = EXCLUDED.insurance_expiry, fitness_expiry = EXCLUDED.fitness_expiry,
         last_service_date = EXCLUDED.last_service_date, last_service_odometer = EXCLUDED.last_service_odometer,
         current_odometer = EXCLUDED.current_odometer`,
      [
        v.id, v.ownerName, v.ownerPhone, v.type, v.brand, v.model, v.registrationNumber,
        v.purchaseDate, v.insuranceExpiry, v.fitnessExpiry, v.lastServiceDate,
        v.lastServiceOdometer, v.currentOdometer, v.serviceIntervalKm, v.serviceIntervalMonths,
      ]
    );
  }
  logger.info(`Seeded ${GARAGE_VEHICLES.length} garage vehicles`);
}

seed().catch((err) => {
  logger.error('Seed failed', err);
  process.exitCode = 1;
});
