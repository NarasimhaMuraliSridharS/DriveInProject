import pg from 'pg';
import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

const { Pool, types } = pg;

// By default node-postgres parses the DATE type (OID 1082) into a JS Date
// object in the server's local timezone, which silently shifts calendar
// dates and renders as a verbose timestamp string. Every DATE column in
// this app (bookings.date, insurance/fitness expiry, service dates) is a
// pure calendar date with no time component, so keep it as the plain
// 'YYYY-MM-DD' string Postgres already sends - simpler and correct.
types.setTypeParser(1082, (value) => value);

export const pool = new Pool({
  connectionString: env.databaseUrl,
  ssl: env.pgSsl ? { rejectUnauthorized: false } : false,
});

// A dropped idle connection shouldn't crash the whole process.
pool.on('error', (err) => {
  logger.error('Unexpected error on idle PostgreSQL client', err);
});
