import { Router } from 'express';
import v1Routes from './v1/index.js';

const router = Router();

router.get('/health', (req, res) => {
  res.json({ success: true, message: 'ok', uptime: process.uptime() });
});

// Versioned under /v1 so a future breaking change (v2) can be added
// and rolled out without touching existing clients.
router.use('/v1', v1Routes);

export default router;
