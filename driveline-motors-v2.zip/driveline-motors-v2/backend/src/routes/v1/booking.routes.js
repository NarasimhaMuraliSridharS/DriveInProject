import { Router } from 'express';
import * as bookingController from '../../controllers/booking.controller.js';
import { validate } from '../../middlewares/validate.js';
import { createBookingSchema, listBookingsQuerySchema } from '../../validators/booking.validators.js';

const router = Router();

router.get('/', validate(listBookingsQuerySchema, 'query'), bookingController.listBookings);
router.post('/', validate(createBookingSchema, 'body'), bookingController.createBooking);
router.get('/:id', bookingController.getBooking);
router.patch('/:id/cancel', bookingController.cancelBooking);
router.delete('/:id', bookingController.deleteBooking);

export default router;
