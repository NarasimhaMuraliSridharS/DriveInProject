import { Router } from 'express';
import * as vehicleController from '../../controllers/vehicle.controller.js';
import { validate } from '../../middlewares/validate.js';
import { listVehiclesQuerySchema, matchVehiclesQuerySchema } from '../../validators/vehicle.validators.js';

const router = Router();

// Static/specific routes must come before the dynamic '/:id' one, or
// Express will try to look up a vehicle with id "brands" or "match".
router.get('/brands', vehicleController.listBrands);
router.get('/match', validate(matchVehiclesQuerySchema, 'query'), vehicleController.matchVehicles);
router.get('/:id', vehicleController.getVehicle);
router.get('/', validate(listVehiclesQuerySchema, 'query'), vehicleController.listVehicles);

export default router;
