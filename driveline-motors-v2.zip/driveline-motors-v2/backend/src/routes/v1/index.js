import { Router } from 'express';
import vehicleRoutes from './vehicle.routes.js';
import bookingRoutes from './booking.routes.js';
import garageRoutes from './garage.routes.js';
import authRoutes from './auth.routes.js';

const router = Router();

router.use('/auth', authRoutes);
router.use('/vehicles', vehicleRoutes);
router.use('/bookings', bookingRoutes);
router.use('/garage', garageRoutes);

export default router;
