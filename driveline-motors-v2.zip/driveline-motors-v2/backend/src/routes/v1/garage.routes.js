import { Router } from 'express';
import * as garageController from '../../controllers/garage.controller.js';
import { validate } from '../../middlewares/validate.js';
import {
  createGarageVehicleSchema,
  updateGarageVehicleSchema,
  listGarageVehiclesQuerySchema,
  createServiceRecordSchema,
  createHealthLogSchema,
} from '../../validators/garage.validators.js';

const router = Router();

// Specific routes before '/:id' for the same reason as vehicle.routes.js.
router.get('/alerts', garageController.listActiveAlerts);

router.get('/vehicles', validate(listGarageVehiclesQuerySchema, 'query'), garageController.listVehicles);
router.post('/vehicles', validate(createGarageVehicleSchema, 'body'), garageController.createVehicle);
router.get('/vehicles/:id', garageController.getVehicle);
router.patch('/vehicles/:id', validate(updateGarageVehicleSchema, 'body'), garageController.updateVehicle);
router.delete('/vehicles/:id', garageController.deleteVehicle);

router.get('/vehicles/:id/service-records', garageController.listServiceRecords);
router.post(
  '/vehicles/:id/service-records',
  validate(createServiceRecordSchema, 'body'),
  garageController.createServiceRecord
);
router.delete('/service-records/:recordId', garageController.deleteServiceRecord);

router.get('/vehicles/:id/health-logs', garageController.listHealthLogs);
router.post(
  '/vehicles/:id/health-logs',
  validate(createHealthLogSchema, 'body'),
  garageController.createHealthLog
);

export default router;
