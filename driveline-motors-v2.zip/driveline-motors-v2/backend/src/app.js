import express from 'express';
import cors from 'cors';
import compression from 'compression';
import { env } from './config/env.js';
import routes from './routes/index.js';
import { requestLogger } from './middlewares/requestLogger.js';
import { optionalAuthenticate } from './middlewares/auth.js';
import { notFoundHandler, errorHandler } from './middlewares/errorHandler.js';

// Pure factory: builds and returns an Express app without starting a
// server. This lets tests import the app and hit it with a fake request
// without ever binding a real port.
export function createApp() {
  const app = express();

  app.use(cors({ origin: env.corsOrigin }));
  app.use(express.json({ limit: '1mb' }));
  app.use(compression());
  app.use(requestLogger);
  // Populates req.user whenever a valid token is sent, on every route,
  // without ever blocking a request that has none - this is what lets
  // guest and logged-in traffic share the same endpoints. Routes that
  // actually need a logged-in user (e.g. GET /auth/me) add `authenticate`
  // on top of this.
  app.use(optionalAuthenticate);

  app.use('/api', routes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
