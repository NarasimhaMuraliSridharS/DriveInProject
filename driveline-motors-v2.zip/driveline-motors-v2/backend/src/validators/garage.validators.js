import { z } from 'zod';
import { VEHICLE_TYPES, HEALTH_LOG_SOURCES } from '../constants/index.js';

const PHONE_REGEX = /^[0-9+\-\s()]{7,15}$/;
const isoDate = () => z.string().refine((v) => !Number.isNaN(Date.parse(v)), 'Invalid date');

export const createGarageVehicleSchema = z.object({
  ownerName: z.string().trim().min(2, 'Owner name must be at least 2 characters').max(80),
  ownerPhone: z.string().trim().regex(PHONE_REGEX, 'Enter a valid phone number'),
  type: z.enum(VEHICLE_TYPES),
  brand: z.string().trim().min(1).max(60),
  model: z.string().trim().min(1).max(60),
  registrationNumber: z.string().trim().min(3).max(20).transform((v) => v.toUpperCase()),
  purchaseDate: isoDate().optional().nullable(),
  insuranceExpiry: isoDate(),
  fitnessExpiry: isoDate(),
  currentOdometer: z.coerce.number().int().nonnegative().optional().default(0),
  serviceIntervalKm: z.coerce.number().int().positive().optional(),
  serviceIntervalMonths: z.coerce.number().int().positive().optional(),
});

// All fields optional on update - only the ones actually sent get changed.
export const updateGarageVehicleSchema = createGarageVehicleSchema.partial();

export const listGarageVehiclesQuerySchema = z.object({
  ownerPhone: z.string().optional(),
});

export const createServiceRecordSchema = z.object({
  serviceDate: isoDate(),
  odometer: z.coerce.number().int().nonnegative(),
  serviceType: z.string().trim().min(1).max(80),
  cost: z.coerce.number().nonnegative().optional().nullable(),
  notes: z.string().max(500).optional().nullable(),
});

export const createHealthLogSchema = z.object({
  source: z.enum(HEALTH_LOG_SOURCES).default('manual'),
  batteryVoltage: z.coerce.number().optional().nullable(),
  fuelLevelPercent: z.coerce.number().min(0).max(100).optional().nullable(),
  odometer: z.coerce.number().int().nonnegative().optional().nullable(),
  engineTempC: z.coerce.number().optional().nullable(),
  dtcCodes: z.string().max(300).optional().nullable(),
  rawPayload: z.any().optional().nullable(),
});
