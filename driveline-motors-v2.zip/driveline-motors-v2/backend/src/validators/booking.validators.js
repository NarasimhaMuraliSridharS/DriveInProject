import { z } from 'zod';
import { SERVICE_TYPES, TIME_SLOTS, BOOKING_STATUSES } from '../constants/index.js';

const PHONE_REGEX = /^[0-9+\-\s()]{7,15}$/;

function isTodayOrLater(dateStr) {
  const input = new Date(dateStr);
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  return input >= startOfToday;
}

export const createBookingSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(80),
  phone: z.string().trim().regex(PHONE_REGEX, 'Enter a valid phone number'),
  vehicleId: z.string().trim().min(1).optional().nullable(),
  vehicleLabel: z.string().trim().max(120).optional().nullable(),
  serviceType: z.enum(SERVICE_TYPES, { errorMap: () => ({ message: 'Unknown service type' }) }),
  date: z
    .string()
    .refine((v) => !Number.isNaN(Date.parse(v)), 'Invalid date')
    .refine(isTodayOrLater, 'Date cannot be in the past'),
  slot: z.enum(TIME_SLOTS, { errorMap: () => ({ message: 'Unknown time slot' }) }),
  notes: z.string().max(500).optional().nullable(),
});

export const listBookingsQuerySchema = z.object({
  status: z.enum(BOOKING_STATUSES).optional(),
  date: z.string().optional(),
  page: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().positive().optional(),
});
