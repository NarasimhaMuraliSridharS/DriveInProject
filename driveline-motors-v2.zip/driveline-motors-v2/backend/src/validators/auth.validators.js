import { z } from 'zod';

const PHONE_REGEX = /^[0-9+\-\s()]{7,15}$/;

export const registerSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(80),
  phone: z.string().trim().regex(PHONE_REGEX, 'Enter a valid phone number'),
  password: z.string().min(6, 'Password must be at least 6 characters').max(72),
});

export const loginSchema = z.object({
  phone: z.string().trim().regex(PHONE_REGEX, 'Enter a valid phone number'),
  password: z.string().min(1, 'Password is required'),
});
