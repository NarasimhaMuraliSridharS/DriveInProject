import { z } from 'zod';
import { VEHICLE_TYPES, CONDITIONS, FUEL_TYPES } from '../constants/index.js';

const optionalEnum = (values) => z.enum(['all', ...values]).optional();

export const listVehiclesQuerySchema = z.object({
  type: optionalEnum(VEHICLE_TYPES),
  condition: optionalEnum(CONDITIONS),
  fuel: optionalEnum(FUEL_TYPES),
  brand: z.string().optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  search: z.string().max(100).optional(),
  sortBy: z.enum(['price_asc', 'price_desc', 'year_desc', 'newest']).optional(),
  page: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().positive().optional(),
});

export const matchVehiclesQuerySchema = z.object({
  budget: z.coerce.number().positive().optional(),
  type: optionalEnum(VEHICLE_TYPES),
  fuel: optionalEnum(FUEL_TYPES),
  limit: z.coerce.number().int().positive().max(20).optional(),
});
