import dotenv from 'dotenv';

dotenv.config();

function required(name, fallback) {
  const value = process.env[name] ?? fallback;
  if (value === undefined) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 4000,
  databaseUrl: required('DATABASE_URL'),
  pgSsl: process.env.PGSSL === 'true',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  logLevel: process.env.LOG_LEVEL || 'info',
  // No hard `required()` here on purpose: forcing a brand-new env var would
  // break `npm run dev` for anyone who already has a working .env from
  // before auth existed. It falls back to an obviously-fake dev secret
  // instead, with a loud warning below if that's actually what's in use.
  jwtSecret: process.env.JWT_SECRET || 'INSECURE_DEV_SECRET_DO_NOT_USE_IN_PRODUCTION',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
};

export const isProd = env.nodeEnv === 'production';

if (!process.env.JWT_SECRET) {
  // eslint-disable-next-line no-console
  console.warn(
    '[WARN] JWT_SECRET is not set - using an insecure default. Set JWT_SECRET in .env before deploying anywhere real.'
  );
}
