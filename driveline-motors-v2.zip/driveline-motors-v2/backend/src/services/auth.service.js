import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { userRepository } from '../repositories/user.repository.js';
import { ApiError } from '../utils/ApiError.js';
import { env } from '../config/env.js';

const SALT_ROUNDS = 10;

// Never return the password hash to a client - this is the one place that
// shapes a DB user row into what's safe to send back or embed in a token.
function toPublicUser(row) {
  return { id: row.id, name: row.name, phone: row.phone, createdAt: row.created_at };
}

function signToken(user) {
  return jwt.sign({ sub: user.id, phone: user.phone }, env.jwtSecret, { expiresIn: env.jwtExpiresIn });
}

export const authService = {
  async register({ name, phone, password }) {
    const existing = await userRepository.findByPhone(phone);
    if (existing) throw ApiError.conflict('An account with this phone number already exists');

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const row = await userRepository.create({ id: randomUUID(), name, phone, passwordHash });
    const user = toPublicUser(row);
    return { user, token: signToken(user) };
  },

  async login({ phone, password }) {
    const row = await userRepository.findByPhone(phone);
    // Same error for "no such phone" and "wrong password" - telling an
    // attacker which one failed would let them enumerate registered phone
    // numbers one guess at a time.
    if (!row) throw ApiError.badRequest('Incorrect phone number or password');

    const passwordMatches = await bcrypt.compare(password, row.password_hash);
    if (!passwordMatches) throw ApiError.badRequest('Incorrect phone number or password');

    const user = toPublicUser(row);
    return { user, token: signToken(user) };
  },

  async getById(id) {
    const row = await userRepository.findById(id);
    if (!row) throw ApiError.notFound('User not found');
    return toPublicUser(row);
  },

  verifyToken(token) {
    return jwt.verify(token, env.jwtSecret); // throws on invalid/expired - caller decides how to handle
  },
};
