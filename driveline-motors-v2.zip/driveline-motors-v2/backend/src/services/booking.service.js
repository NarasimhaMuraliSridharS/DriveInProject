import { randomUUID } from 'node:crypto';
import { bookingRepository } from '../repositories/booking.repository.js';
import { vehicleRepository } from '../repositories/vehicle.repository.js';
import { ApiError } from '../utils/ApiError.js';
import { BOOKING_STATUS, MAX_BOOKINGS_PER_SLOT } from '../constants/index.js';
import { parsePagination, buildMeta } from '../utils/pagination.js';

// Deterministic integer key for Postgres advisory locks, derived from
// "date:slot" so two requests for the same slot always contend for the
// same lock - this is what actually prevents overbooking under load,
// not just the COUNT(*) check on its own.
function slotLockKey(date, slot) {
  const str = `${date}:${slot}`;
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    hash = (hash * 31 + str.charCodeAt(i)) | 0;
  }
  return hash;
}

export const bookingService = {
  async list(query) {
    const { page, limit, offset } = parsePagination(query);
    const { rows, total } = await bookingRepository.findMany(query, { limit, offset });
    return { items: rows, meta: buildMeta({ page, limit, total }) };
  },

  async getById(id) {
    const booking = await bookingRepository.findById(id);
    if (!booking) throw ApiError.notFound(`Booking ${id} not found`);
    return booking;
  },

  async create(payload) {
    let vehicleLabel = payload.vehicleLabel || null;

    if (payload.vehicleId) {
      const vehicle = await vehicleRepository.findById(payload.vehicleId);
      if (!vehicle) throw ApiError.badRequest('Selected vehicle does not exist');
      vehicleLabel = `${vehicle.brand} ${vehicle.model}`;
    }

    return bookingRepository.withTransaction(async (client) => {
      await client.query('SELECT pg_advisory_xact_lock($1)', [slotLockKey(payload.date, payload.slot)]);

      const currentCount = await bookingRepository.countForSlot(payload.date, payload.slot, client);
      if (currentCount >= MAX_BOOKINGS_PER_SLOT) {
        throw ApiError.conflict(
          `The ${payload.slot} slot on ${payload.date} is fully booked. Please choose another slot.`
        );
      }

      return bookingRepository.create(
        { id: randomUUID(), ...payload, vehicleLabel, status: BOOKING_STATUS.REQUESTED },
        client
      );
    });
  },

  async cancel(id) {
    const booking = await bookingRepository.findById(id);
    if (!booking) throw ApiError.notFound(`Booking ${id} not found`);
    if (booking.status === BOOKING_STATUS.CANCELLED) return booking;
    return bookingRepository.updateStatus(id, BOOKING_STATUS.CANCELLED);
  },

  async remove(id) {
    const deleted = await bookingRepository.remove(id);
    if (!deleted) throw ApiError.notFound(`Booking ${id} not found`);
  },
};
