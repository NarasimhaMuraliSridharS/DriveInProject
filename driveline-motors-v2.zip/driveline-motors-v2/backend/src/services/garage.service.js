import { randomUUID } from 'node:crypto';
import { garageVehicleRepository } from '../repositories/garageVehicle.repository.js';
import { serviceRecordRepository } from '../repositories/serviceRecord.repository.js';
import { healthLogRepository } from '../repositories/healthLog.repository.js';
import { computeVehicleAlerts, worstLevel } from './alert.service.js';
import { ApiError } from '../utils/ApiError.js';
import { DEFAULT_SERVICE_INTERVAL_KM, DEFAULT_SERVICE_INTERVAL_MONTHS } from '../constants/index.js';

// The DB layer speaks snake_case (Postgres convention); everything above
// the repository speaks camelCase (JS convention). This is the one seam
// where that translation happens, so alert.service.js never has to care.
function toCamel(row) {
  if (!row) return row;
  return {
    id: row.id,
    ownerName: row.owner_name,
    ownerPhone: row.owner_phone,
    type: row.type,
    brand: row.brand,
    model: row.model,
    registrationNumber: row.registration_number,
    purchaseDate: row.purchase_date,
    insuranceExpiry: row.insurance_expiry,
    fitnessExpiry: row.fitness_expiry,
    lastServiceDate: row.last_service_date,
    lastServiceOdometer: row.last_service_odometer,
    currentOdometer: row.current_odometer,
    serviceIntervalKm: row.service_interval_km,
    serviceIntervalMonths: row.service_interval_months,
    createdAt: row.created_at,
  };
}

function withAlerts(vehicle) {
  const alerts = computeVehicleAlerts(vehicle);
  return { ...vehicle, alerts, alertLevel: worstLevel(alerts) };
}

export const garageService = {
  async list(query) {
    const rows = await garageVehicleRepository.findMany(query);
    return rows.map(toCamel).map(withAlerts);
  },

  async getById(id) {
    const row = await garageVehicleRepository.findById(id);
    if (!row) throw ApiError.notFound(`Garage vehicle ${id} not found`);
    const vehicle = withAlerts(toCamel(row));
    const [serviceRecords, latestHealthLog] = await Promise.all([
      serviceRecordRepository.findByVehicle(id),
      healthLogRepository.findLatest(id),
    ]);
    return { ...vehicle, serviceRecords, latestHealthLog };
  },

  // Flat, cross-vehicle list of only the alerts that need attention - what
  // the notification bell in the nav polls.
  async activeAlerts() {
    const vehicles = await this.list();
    return vehicles
      .flatMap((v) =>
        v.alerts
          .filter((a) => a.level !== 'ok')
          .map((a) => ({ ...a, vehicleId: v.id, vehicleLabel: `${v.brand} ${v.model} (${v.registrationNumber})` }))
      )
      .sort((a, b) => (a.level === b.level ? 0 : a.level === 'overdue' ? -1 : 1));
  },

  async create(payload) {
    const existing = await garageVehicleRepository.findByRegistration(payload.registrationNumber);
    if (existing) throw ApiError.conflict(`A vehicle with registration ${payload.registrationNumber} already exists`);

    const row = await garageVehicleRepository.create({
      id: randomUUID(),
      ...payload,
      serviceIntervalKm: payload.serviceIntervalKm || DEFAULT_SERVICE_INTERVAL_KM,
      serviceIntervalMonths: payload.serviceIntervalMonths || DEFAULT_SERVICE_INTERVAL_MONTHS,
    });
    return withAlerts(toCamel(row));
  },

  async update(id, fields) {
    const existing = await garageVehicleRepository.findById(id);
    if (!existing) throw ApiError.notFound(`Garage vehicle ${id} not found`);

    if (fields.registrationNumber && fields.registrationNumber !== existing.registration_number) {
      const clash = await garageVehicleRepository.findByRegistration(fields.registrationNumber);
      if (clash) throw ApiError.conflict(`A vehicle with registration ${fields.registrationNumber} already exists`);
    }

    const row = await garageVehicleRepository.update(id, fields);
    return withAlerts(toCamel(row));
  },

  async remove(id) {
    const deleted = await garageVehicleRepository.remove(id);
    if (!deleted) throw ApiError.notFound(`Garage vehicle ${id} not found`);
  },

  async addServiceRecord(vehicleId, payload) {
    const vehicle = await garageVehicleRepository.findById(vehicleId);
    if (!vehicle) throw ApiError.notFound(`Garage vehicle ${vehicleId} not found`);

    return serviceRecordRepository.withTransaction(async (client) => {
      const record = await serviceRecordRepository.create(
        { id: randomUUID(), garageVehicleId: vehicleId, ...payload },
        client
      );

      // A new service record only moves "last service" forward in time -
      // logging an old receipt shouldn't regress the vehicle's due dates.
      const isNewer = !vehicle.last_service_date || new Date(payload.serviceDate) >= new Date(vehicle.last_service_date);
      if (isNewer) {
        await client.query(
          `UPDATE garage_vehicles
             SET last_service_date = $1, last_service_odometer = $2,
                 current_odometer = GREATEST(current_odometer, $2)
           WHERE id = $3`,
          [payload.serviceDate, payload.odometer, vehicleId]
        );
      }
      return record;
    });
  },

  async listServiceRecords(vehicleId) {
    const vehicle = await garageVehicleRepository.findById(vehicleId);
    if (!vehicle) throw ApiError.notFound(`Garage vehicle ${vehicleId} not found`);
    return serviceRecordRepository.findByVehicle(vehicleId);
  },

  async removeServiceRecord(recordId) {
    const deleted = await serviceRecordRepository.remove(recordId);
    if (!deleted) throw ApiError.notFound(`Service record ${recordId} not found`);
  },

  async addHealthLog(vehicleId, payload) {
    const vehicle = await garageVehicleRepository.findById(vehicleId);
    if (!vehicle) throw ApiError.notFound(`Garage vehicle ${vehicleId} not found`);

    const log = await healthLogRepository.create({ id: randomUUID(), garageVehicleId: vehicleId, ...payload });

    if (payload.odometer != null && payload.odometer > vehicle.current_odometer) {
      await garageVehicleRepository.update(vehicleId, { currentOdometer: payload.odometer });
    }
    return log;
  },

  async listHealthLogs(vehicleId) {
    const vehicle = await garageVehicleRepository.findById(vehicleId);
    if (!vehicle) throw ApiError.notFound(`Garage vehicle ${vehicleId} not found`);
    return healthLogRepository.findByVehicle(vehicleId);
  },
};
