import { ALERT_LEVEL, ALERT_TYPE, ALERT_WARNING_DAYS, ALERT_WARNING_KM } from '../constants/index.js';

const MS_PER_DAY = 1000 * 60 * 60 * 24;

function daysBetween(fromDate, toDate) {
  return Math.round((toDate.getTime() - fromDate.getTime()) / MS_PER_DAY);
}

function addMonths(date, months) {
  const result = new Date(date);
  result.setMonth(result.getMonth() + months);
  return result;
}

// A date-based alert (insurance, RC fitness). `now` is injectable so this
// stays a pure, unit-testable function instead of reaching for `new Date()`
// internally.
export function computeDateAlert(type, label, dueDateStr, now = new Date()) {
  const dueDate = new Date(dueDateStr);
  const daysRemaining = daysBetween(now, dueDate);

  let level = ALERT_LEVEL.OK;
  let message = `${label} valid until ${dueDateStr}.`;

  if (daysRemaining < 0) {
    level = ALERT_LEVEL.OVERDUE;
    message = `${label} expired ${Math.abs(daysRemaining)} day(s) ago.`;
  } else if (daysRemaining <= ALERT_WARNING_DAYS) {
    level = ALERT_LEVEL.WARNING;
    message = `${label} expires in ${daysRemaining} day(s).`;
  }

  return { type, label, level, dueDate: dueDateStr, daysRemaining, message };
}

// Service-due alert: whichever comes sooner of (a) distance since last
// service vs. the km interval, or (b) time since last service vs. the
// month interval - a car driven hard hits the km limit first, a car that
// sits in a garage hits the time limit first.
export function computeServiceAlert(vehicle, now = new Date()) {
  const label = 'Service';
  const {
    lastServiceDate,
    lastServiceOdometer,
    currentOdometer,
    serviceIntervalKm,
    serviceIntervalMonths,
  } = vehicle;

  const baseOdometer = lastServiceOdometer ?? 0;
  const kmSinceService = currentOdometer - baseOdometer;
  const kmRemaining = serviceIntervalKm - kmSinceService;

  let daysRemaining = null;
  let dueDate = null;
  if (lastServiceDate) {
    dueDate = addMonths(new Date(lastServiceDate), serviceIntervalMonths);
    daysRemaining = daysBetween(now, dueDate);
  }

  // Normalize both signals onto "how far past due, in the more urgent unit"
  // by picking whichever metric is more overdue/closer to due.
  const kmLevel = kmRemaining < 0
    ? ALERT_LEVEL.OVERDUE
    : kmRemaining <= ALERT_WARNING_KM
      ? ALERT_LEVEL.WARNING
      : ALERT_LEVEL.OK;

  const dateLevel = daysRemaining === null
    ? ALERT_LEVEL.OK
    : daysRemaining < 0
      ? ALERT_LEVEL.OVERDUE
      : daysRemaining <= ALERT_WARNING_DAYS
        ? ALERT_LEVEL.WARNING
        : ALERT_LEVEL.OK;

  const rank = { [ALERT_LEVEL.OK]: 0, [ALERT_LEVEL.WARNING]: 1, [ALERT_LEVEL.OVERDUE]: 2 };
  const level = rank[kmLevel] >= rank[dateLevel] ? kmLevel : dateLevel;

  let message;
  if (level === ALERT_LEVEL.OVERDUE) {
    const overdueBy = kmRemaining < 0 ? `${Math.abs(kmRemaining)} km` : `${Math.abs(daysRemaining)} day(s)`;
    message = `Service overdue by ${overdueBy}.`;
  } else if (level === ALERT_LEVEL.WARNING) {
    const dueIn = kmLevel === level ? `${kmRemaining} km` : `${daysRemaining} day(s)`;
    message = `Service due in ${dueIn}.`;
  } else {
    message = lastServiceDate
      ? `Next service due in ${kmRemaining} km or by ${dueDate.toISOString().slice(0, 10)}.`
      : `No service logged yet. Next service due within ${serviceIntervalKm} km.`;
  }

  return {
    type: ALERT_TYPE.SERVICE,
    label,
    level,
    dueDate: dueDate ? dueDate.toISOString().slice(0, 10) : null,
    kmRemaining,
    daysRemaining,
    message,
  };
}

export function computeVehicleAlerts(vehicle, now = new Date()) {
  return [
    computeDateAlert(ALERT_TYPE.INSURANCE, 'Insurance', vehicle.insuranceExpiry, now),
    computeDateAlert(ALERT_TYPE.FITNESS, 'RC fitness', vehicle.fitnessExpiry, now),
    computeServiceAlert(vehicle, now),
  ];
}

export function worstLevel(alerts) {
  const rank = { [ALERT_LEVEL.OK]: 0, [ALERT_LEVEL.WARNING]: 1, [ALERT_LEVEL.OVERDUE]: 2 };
  return alerts.reduce((worst, a) => (rank[a.level] > rank[worst] ? a.level : worst), ALERT_LEVEL.OK);
}
