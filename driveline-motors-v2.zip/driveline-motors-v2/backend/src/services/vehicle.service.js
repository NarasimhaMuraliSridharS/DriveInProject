import { vehicleRepository } from '../repositories/vehicle.repository.js';
import { ApiError } from '../utils/ApiError.js';
import { parsePagination, buildMeta } from '../utils/pagination.js';

export const vehicleService = {
  async list(query) {
    const { page, limit, offset } = parsePagination(query);
    const { rows, total } = await vehicleRepository.findMany(query, { limit, offset });
    return { items: rows, meta: buildMeta({ page, limit, total }) };
  },

  async getById(id) {
    const vehicle = await vehicleRepository.findById(id);
    if (!vehicle) throw ApiError.notFound(`Vehicle ${id} not found`);
    return vehicle;
  },

  async listBrands() {
    return vehicleRepository.listBrands();
  },

  // Ranks vehicles against a soft preference (budget/type/fuel) instead of
  // hard-filtering them out - a slightly-over-budget SUV can still beat an
  // in-budget car that ignores every other preference.
  async match({ budget, type, fuel, limit = 5 }) {
    const candidates = await vehicleRepository.findAll({ type, fuel });
    const preference = { budget, type, fuel };

    const scored = candidates.map((vehicle) => ({
      vehicle,
      score: scoreVehicle(vehicle, preference),
    }));

    scored.sort((a, b) => b.score - a.score);

    return scored.slice(0, limit).map(({ vehicle, score }) => ({
      ...vehicle,
      matchScore: Number(score.toFixed(2)),
    }));
  },
};

function scoreVehicle(vehicle, preference) {
  let score = 0;

  if (preference.budget) {
    score += vehicle.price <= preference.budget
      ? 2 - (preference.budget - vehicle.price) / preference.budget
      : -((vehicle.price - preference.budget) / preference.budget);
  }
  if (preference.type && preference.type !== 'all' && vehicle.type === preference.type) score += 1;
  if (preference.fuel && preference.fuel !== 'all' && vehicle.fuel === preference.fuel) score += 1;

  return score;
}
