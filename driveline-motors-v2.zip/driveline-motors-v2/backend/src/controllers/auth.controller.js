import { authService } from '../services/auth.service.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import { sendSuccess } from '../utils/ApiResponse.js';

export const register = asyncHandler(async (req, res) => {
  const { user, token } = await authService.register(req.body);
  sendSuccess(res, { data: { user, token }, statusCode: 201, message: 'Account created' });
});

export const login = asyncHandler(async (req, res) => {
  const { user, token } = await authService.login(req.body);
  sendSuccess(res, { data: { user, token }, message: 'Logged in' });
});

export const me = asyncHandler(async (req, res) => {
  const user = await authService.getById(req.user.id);
  sendSuccess(res, { data: user });
});
