import { bookingService } from '../services/booking.service.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import { sendSuccess } from '../utils/ApiResponse.js';

export const listBookings = asyncHandler(async (req, res) => {
  const { items, meta } = await bookingService.list(req.query);
  sendSuccess(res, { data: items, meta });
});

export const getBooking = asyncHandler(async (req, res) => {
  const booking = await bookingService.getById(req.params.id);
  sendSuccess(res, { data: booking });
});

export const createBooking = asyncHandler(async (req, res) => {
  const booking = await bookingService.create(req.body);
  sendSuccess(res, { data: booking, statusCode: 201, message: 'Booking request received' });
});

export const cancelBooking = asyncHandler(async (req, res) => {
  const booking = await bookingService.cancel(req.params.id);
  sendSuccess(res, { data: booking, message: 'Booking cancelled' });
});

export const deleteBooking = asyncHandler(async (req, res) => {
  await bookingService.remove(req.params.id);
  res.status(204).end();
});
