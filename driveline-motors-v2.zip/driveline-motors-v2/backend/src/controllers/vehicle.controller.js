import { vehicleService } from '../services/vehicle.service.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import { sendSuccess } from '../utils/ApiResponse.js';

// Controllers stay thin on purpose: pull input off `req`, call one
// service method, shape the response. No SQL, no business rules here.

export const listVehicles = asyncHandler(async (req, res) => {
  const { items, meta } = await vehicleService.list(req.query);
  sendSuccess(res, { data: items, meta, message: 'Vehicles fetched successfully' });
});

export const getVehicle = asyncHandler(async (req, res) => {
  const vehicle = await vehicleService.getById(req.params.id);
  sendSuccess(res, { data: vehicle });
});

export const listBrands = asyncHandler(async (req, res) => {
  const brands = await vehicleService.listBrands();
  sendSuccess(res, { data: brands });
});

export const matchVehicles = asyncHandler(async (req, res) => {
  const results = await vehicleService.match(req.query);
  sendSuccess(res, { data: results, message: 'Ranked by match' });
});
