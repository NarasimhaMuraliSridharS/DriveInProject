import { garageService } from '../services/garage.service.js';
import { asyncHandler } from '../middlewares/asyncHandler.js';
import { sendSuccess } from '../utils/ApiResponse.js';

export const listVehicles = asyncHandler(async (req, res) => {
  const vehicles = await garageService.list(req.query);
  sendSuccess(res, { data: vehicles });
});

export const getVehicle = asyncHandler(async (req, res) => {
  const vehicle = await garageService.getById(req.params.id);
  sendSuccess(res, { data: vehicle });
});

export const createVehicle = asyncHandler(async (req, res) => {
  const vehicle = await garageService.create(req.body);
  sendSuccess(res, { data: vehicle, statusCode: 201, message: 'Vehicle added to garage' });
});

export const updateVehicle = asyncHandler(async (req, res) => {
  const vehicle = await garageService.update(req.params.id, req.body);
  sendSuccess(res, { data: vehicle, message: 'Vehicle updated' });
});

export const deleteVehicle = asyncHandler(async (req, res) => {
  await garageService.remove(req.params.id);
  res.status(204).end();
});

export const listActiveAlerts = asyncHandler(async (req, res) => {
  const alerts = await garageService.activeAlerts();
  sendSuccess(res, { data: alerts });
});

export const listServiceRecords = asyncHandler(async (req, res) => {
  const records = await garageService.listServiceRecords(req.params.id);
  sendSuccess(res, { data: records });
});

export const createServiceRecord = asyncHandler(async (req, res) => {
  const record = await garageService.addServiceRecord(req.params.id, req.body);
  sendSuccess(res, { data: record, statusCode: 201, message: 'Service record logged' });
});

export const deleteServiceRecord = asyncHandler(async (req, res) => {
  await garageService.removeServiceRecord(req.params.recordId);
  res.status(204).end();
});

export const listHealthLogs = asyncHandler(async (req, res) => {
  const logs = await garageService.listHealthLogs(req.params.id);
  sendSuccess(res, { data: logs });
});

export const createHealthLog = asyncHandler(async (req, res) => {
  const log = await garageService.addHealthLog(req.params.id, req.body);
  sendSuccess(res, { data: log, statusCode: 201, message: 'Health reading logged' });
});
