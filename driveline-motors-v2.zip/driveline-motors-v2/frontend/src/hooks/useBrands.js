import { useEffect, useState } from 'react'
import { vehiclesApi } from '../api/vehicles.api.js'

export function useBrands() {
  const [brands, setBrands] = useState([])

  useEffect(() => {
    vehiclesApi.brands().then((res) => setBrands(res.data)).catch(() => {})
  }, [])

  return brands
}
