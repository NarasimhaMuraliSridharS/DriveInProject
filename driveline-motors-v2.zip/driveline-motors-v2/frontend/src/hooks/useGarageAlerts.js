import { useEffect, useState, useCallback } from 'react'
import { garageApi } from '../api/garage.api.js'

const POLL_INTERVAL_MS = 60_000

// Polls the active-alerts endpoint so the notification bell stays current
// without the user having to manually refresh the page.
export function useGarageAlerts() {
  const [alerts, setAlerts] = useState([])
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(() => {
    return garageApi.alerts()
      .then((res) => setAlerts(res.data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    refresh()
    const interval = setInterval(refresh, POLL_INTERVAL_MS)
    return () => clearInterval(interval)
  }, [refresh])

  return { alerts, loading, refresh }
}
