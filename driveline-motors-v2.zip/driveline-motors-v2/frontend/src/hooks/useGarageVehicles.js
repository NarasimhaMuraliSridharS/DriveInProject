import { useCallback, useEffect, useState } from 'react'
import { garageApi } from '../api/garage.api.js'

export function useGarageVehicles() {
  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refresh = useCallback(() => {
    setLoading(true)
    setError(null)
    return garageApi.listVehicles()
      .then((res) => setVehicles(res.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { refresh() }, [refresh])

  return { vehicles, loading, error, refresh }
}
