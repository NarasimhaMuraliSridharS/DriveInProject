import { useCallback, useEffect, useState } from 'react'
import { bookingsApi } from '../api/bookings.api.js'

export function useBookings() {
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refresh = useCallback(() => {
    setLoading(true)
    setError(null)
    return bookingsApi
      .list()
      .then((res) => setBookings(res.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  return { bookings, loading, error, refresh }
}
