import { useEffect, useState } from 'react'
import { vehiclesApi } from '../api/vehicles.api.js'

// Deliberately calls the server's /vehicles/match endpoint rather than
// re-implementing the scoring formula in the browser - one algorithm,
// one place, so the UI can never drift out of sync with the API.
export function useVehicleMatch(preference) {
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const preferenceKey = JSON.stringify(preference)

  useEffect(() => {
    if (!preference) {
      setResults([])
      return
    }
    const controller = new AbortController()
    setLoading(true)
    vehiclesApi
      .match({ ...preference, limit: 12 }, { signal: controller.signal })
      .then((res) => setResults(res.data))
      .catch((err) => {
        if (err.name !== 'AbortError') setResults([])
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false)
      })

    return () => controller.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preferenceKey])

  return { results, loading }
}
