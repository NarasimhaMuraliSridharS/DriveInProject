import { useCallback, useRef, useState } from 'react'

// Service UUIDs worth asking for by name: the standard Battery Service,
// plus the two most common "serial over BLE" services that cheap OBD/BLE
// dongles tend to expose (Nordic UART, and the HM-10-style FFE0 service).
// This is NOT a full OBD-II PID decoder - there is no single standard for
// how BLE OBD adapters expose data, so this hook connects, discovers
// whatever services/characteristics the device actually has, and surfaces
// raw bytes. Decoding those bytes into "engine RPM" etc. is adapter-specific.
const KNOWN_SERVICES = [
  'battery_service',
  '6e400001-b5a3-f393-e0a9-e50e24dcca9e', // Nordic UART Service
  '0000ffe0-0000-1000-8000-00805f9b34fb', // common HM-10 / cheap BLE UART module
]

function toHex(dataView) {
  const bytes = new Uint8Array(dataView.buffer)
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join(' ')
}

export function useVehicleBluetooth() {
  const [supported] = useState(() => typeof navigator !== 'undefined' && 'bluetooth' in navigator)
  const [connecting, setConnecting] = useState(false)
  const [connected, setConnected] = useState(false)
  const [deviceName, setDeviceName] = useState(null)
  const [error, setError] = useState(null)
  const [readings, setReadings] = useState([])
  const deviceRef = useRef(null)

  const handleDisconnected = useCallback(() => {
    setConnected(false)
    setDeviceName(null)
  }, [])

  const recordReading = useCallback((serviceUuid, characteristicUuid, dataView) => {
    setReadings((prev) => [
      { id: crypto.randomUUID(), timestamp: new Date().toISOString(), serviceUuid, characteristicUuid, hex: toHex(dataView) },
      ...prev,
    ].slice(0, 30))
  }, [])

  const connect = useCallback(async () => {
    if (!supported) {
      setError('Web Bluetooth is not available in this browser. Try Chrome or Edge on desktop or Android — Safari and Firefox do not support it.')
      return
    }
    setError(null)
    setConnecting(true)
    try {
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: KNOWN_SERVICES,
      })
      deviceRef.current = device
      device.addEventListener('gattserverdisconnected', handleDisconnected)

      const server = await device.gatt.connect()
      setDeviceName(device.name || 'Unnamed Bluetooth device')
      setConnected(true)

      const services = await server.getPrimaryServices()
      for (const service of services) {
        const characteristics = await service.getCharacteristics()
        for (const characteristic of characteristics) {
          if (characteristic.properties.notify) {
            characteristic.addEventListener('characteristicvaluechanged', (event) => {
              recordReading(service.uuid, characteristic.uuid, event.target.value)
            })
            await characteristic.startNotifications()
          } else if (characteristic.properties.read) {
            try {
              const value = await characteristic.readValue()
              recordReading(service.uuid, characteristic.uuid, value)
            } catch {
              // Some characteristics advertise "read" but reject it without
              // extra pairing/authorization - skip rather than fail the
              // whole connection over one characteristic.
            }
          }
        }
      }
    } catch (err) {
      if (err.name !== 'NotFoundError') { // user closed the device picker - not a real error
        setError(err.message || 'Could not connect to the device.')
      }
      setConnected(false)
    } finally {
      setConnecting(false)
    }
  }, [supported, handleDisconnected, recordReading])

  const disconnect = useCallback(() => {
    deviceRef.current?.gatt?.disconnect()
    setConnected(false)
    setDeviceName(null)
  }, [])

  return { supported, connecting, connected, deviceName, error, readings, connect, disconnect }
}
