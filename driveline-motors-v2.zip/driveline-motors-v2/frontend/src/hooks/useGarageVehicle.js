import { useCallback, useEffect, useState } from 'react'
import { garageApi } from '../api/garage.api.js'

export function useGarageVehicle(id) {
  const [vehicle, setVehicle] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refresh = useCallback(() => {
    if (!id) return
    setLoading(true)
    setError(null)
    return garageApi.getVehicle(id)
      .then((res) => setVehicle(res.data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [id])

  useEffect(() => { refresh() }, [refresh])

  return { vehicle, loading, error, refresh }
}
