import { useEffect, useRef, useState } from 'react'
import { vehiclesApi } from '../api/vehicles.api.js'

// Fetches the filtered/paginated vehicle list. Cancels the previous
// in-flight request whenever filters change, so a slow early response
// can never overwrite a later, more relevant one.
export function useVehicles(filters) {
  const [vehicles, setVehicles] = useState([])
  const [meta, setMeta] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const filtersKey = JSON.stringify(filters)

  useEffect(() => {
    const controller = new AbortController()

    setLoading(true)
    setError(null)

    vehiclesApi
      .list(filters, { signal: controller.signal })
      .then((res) => {
        setVehicles(res.data)
        setMeta(res.meta)
      })
      .catch((err) => {
        if (err.name !== 'AbortError') setError(err.message)
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false)
      })

    return () => controller.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtersKey])

  return { vehicles, meta, loading, error }
}
