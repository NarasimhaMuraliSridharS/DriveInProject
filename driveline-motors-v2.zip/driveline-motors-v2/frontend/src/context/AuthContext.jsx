import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { authApi } from '../api/auth.api.js'
import { setAuthToken, getAuthToken, onUnauthorized } from '../api/client.js'

const AuthContext = createContext(null)
const GUEST_STORAGE_KEY = 'driveline-guest-mode'

// Four states the rest of the app can be in:
//   'loading'        - still checking whether a saved token is valid
//   'authenticated'  - real logged-in user, req.user set on every API call
//   'guest'          - explicitly chose to skip login; same API access,
//                       just nothing persisted under an account
//   'unauthenticated' - neither: show the login/register/guest screen

export function AuthProvider({ children }) {
  const [status, setStatus] = useState('loading')
  const [user, setUser] = useState(null)

  // On first load, a saved token is re-validated against the server rather
  // than trusted blindly - a token that's been revoked or expired since the
  // last visit should drop the person back to logged-out, not show a user
  // object the API will then reject on every call.
  useEffect(() => {
    const token = getAuthToken()
    if (!token) {
      setStatus(localStorage.getItem(GUEST_STORAGE_KEY) === 'true' ? 'guest' : 'unauthenticated')
      return
    }
    authApi.me()
      .then((res) => {
        setUser(res.data)
        setStatus('authenticated')
      })
      .catch(() => {
        setAuthToken(null)
        setStatus(localStorage.getItem(GUEST_STORAGE_KEY) === 'true' ? 'guest' : 'unauthenticated')
      })
  }, [])

  // Any other API call that comes back 401 (token expired mid-session,
  // say) drops the app back to logged-out from wherever it was.
  useEffect(() => {
    return onUnauthorized(() => {
      setAuthToken(null)
      setUser(null)
      setStatus('unauthenticated')
    })
  }, [])

  const login = useCallback(async (phone, password) => {
    const res = await authApi.login({ phone, password })
    setAuthToken(res.data.token)
    localStorage.removeItem(GUEST_STORAGE_KEY)
    setUser(res.data.user)
    setStatus('authenticated')
  }, [])

  const register = useCallback(async (name, phone, password) => {
    const res = await authApi.register({ name, phone, password })
    setAuthToken(res.data.token)
    localStorage.removeItem(GUEST_STORAGE_KEY)
    setUser(res.data.user)
    setStatus('authenticated')
  }, [])

  const continueAsGuest = useCallback(() => {
    localStorage.setItem(GUEST_STORAGE_KEY, 'true')
    setStatus('guest')
  }, [])

  const logout = useCallback(() => {
    setAuthToken(null)
    localStorage.removeItem(GUEST_STORAGE_KEY)
    setUser(null)
    setStatus('unauthenticated')
  }, [])

  return (
    <AuthContext.Provider value={{ status, user, login, register, continueAsGuest, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
