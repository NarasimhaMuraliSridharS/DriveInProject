import { apiClient } from './client.js'

function toQueryString(params = {}) {
  const usp = new URLSearchParams()
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== 'all') {
      usp.set(key, value)
    }
  })
  const qs = usp.toString()
  return qs ? `?${qs}` : ''
}

export const vehiclesApi = {
  list: (filters, opts) => apiClient.get(`/v1/vehicles${toQueryString(filters)}`, opts),
  getById: (id, opts) => apiClient.get(`/v1/vehicles/${id}`, opts),
  brands: (opts) => apiClient.get('/v1/vehicles/brands', opts),
  match: (preference, opts) => apiClient.get(`/v1/vehicles/match${toQueryString(preference)}`, opts),
}
