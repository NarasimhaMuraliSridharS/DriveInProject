// Thin fetch wrapper: every API call goes through here, so the base
// URL, JSON handling, auth header and error shape are defined in exactly
// one place.
const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'
const TOKEN_STORAGE_KEY = 'driveline-auth-token'

export class ApiClientError extends Error {
  constructor(message, status, details) {
    super(message)
    this.name = 'ApiClientError'
    this.status = status
    this.details = details
  }
}

// Module-level cache of the token so every request doesn't have to touch
// localStorage - AuthContext is the only thing that calls setAuthToken,
// right after login/register/logout/hydration from storage.
let currentToken = (() => {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY)
  } catch {
    return null
  }
})()

// Listeners AuthContext can register to react to a 401 from *any* request
// (not just /auth/me) - e.g. the token expired mid-session on some other
// call, and the app should drop back to guest/logged-out state everywhere.
const unauthorizedListeners = new Set()

export function setAuthToken(token) {
  currentToken = token
  try {
    if (token) localStorage.setItem(TOKEN_STORAGE_KEY, token)
    else localStorage.removeItem(TOKEN_STORAGE_KEY)
  } catch {
    // Storage can throw in private-browsing/blocked-cookie contexts; the
    // in-memory token still works for the rest of this tab's session.
  }
}

export function getAuthToken() {
  return currentToken
}

export function onUnauthorized(listener) {
  unauthorizedListeners.add(listener)
  return () => unauthorizedListeners.delete(listener)
}

async function request(path, { method = 'GET', body, signal, skipAuth = false } = {}) {
  const headers = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (currentToken && !skipAuth) headers.Authorization = `Bearer ${currentToken}`

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
    signal,
  })

  const isJson = res.headers.get('content-type')?.includes('application/json')
  const payload = isJson ? await res.json().catch(() => null) : null

  if (!res.ok) {
    if (res.status === 401 && currentToken && !skipAuth) {
      unauthorizedListeners.forEach((listener) => listener())
    }
    throw new ApiClientError(
      payload?.message || `Request failed with status ${res.status}`,
      res.status,
      payload?.details
    )
  }

  return payload
}

export const apiClient = {
  get: (path, opts) => request(path, { ...opts, method: 'GET' }),
  post: (path, body, opts) => request(path, { ...opts, method: 'POST', body }),
  patch: (path, body, opts) => request(path, { ...opts, method: 'PATCH', body }),
  delete: (path, opts) => request(path, { ...opts, method: 'DELETE' }),
}
