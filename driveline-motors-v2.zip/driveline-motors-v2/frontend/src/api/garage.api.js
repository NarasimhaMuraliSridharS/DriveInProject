import { apiClient } from './client.js'

export const garageApi = {
  listVehicles: (opts) => apiClient.get('/v1/garage/vehicles', opts),
  getVehicle: (id, opts) => apiClient.get(`/v1/garage/vehicles/${id}`, opts),
  createVehicle: (payload) => apiClient.post('/v1/garage/vehicles', payload),
  updateVehicle: (id, payload) => apiClient.patch(`/v1/garage/vehicles/${id}`, payload),
  removeVehicle: (id) => apiClient.delete(`/v1/garage/vehicles/${id}`),

  alerts: (opts) => apiClient.get('/v1/garage/alerts', opts),

  listServiceRecords: (vehicleId) => apiClient.get(`/v1/garage/vehicles/${vehicleId}/service-records`),
  addServiceRecord: (vehicleId, payload) => apiClient.post(`/v1/garage/vehicles/${vehicleId}/service-records`, payload),
  removeServiceRecord: (recordId) => apiClient.delete(`/v1/garage/service-records/${recordId}`),

  listHealthLogs: (vehicleId) => apiClient.get(`/v1/garage/vehicles/${vehicleId}/health-logs`),
  addHealthLog: (vehicleId, payload) => apiClient.post(`/v1/garage/vehicles/${vehicleId}/health-logs`, payload),
}
