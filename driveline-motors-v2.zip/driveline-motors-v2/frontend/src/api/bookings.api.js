import { apiClient } from './client.js'

export const bookingsApi = {
  list: (opts) => apiClient.get('/v1/bookings', opts),
  create: (payload) => apiClient.post('/v1/bookings', payload),
  cancel: (id) => apiClient.patch(`/v1/bookings/${id}/cancel`),
  remove: (id) => apiClient.delete(`/v1/bookings/${id}`),
}
