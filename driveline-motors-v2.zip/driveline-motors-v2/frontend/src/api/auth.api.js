import { apiClient } from './client.js'

export const authApi = {
  register: (payload) => apiClient.post('/v1/auth/register', payload, { skipAuth: true }),
  login: (payload) => apiClient.post('/v1/auth/login', payload, { skipAuth: true }),
  me: () => apiClient.get('/v1/auth/me'),
}
