import { useState } from 'react'
import { useAuth } from '../../context/AuthContext.jsx'
import Field from '../../components/ui/Field.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'

export default function AuthPage() {
  const { login, register, continueAsGuest } = useAuth()
  const [mode, setMode] = useState('login') // 'login' | 'register'
  const [form, setForm] = useState({ name: '', phone: '', password: '' })
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  function set(key, value) { setForm({ ...form, [key]: value }) }

  function switchMode(nextMode) {
    setMode(nextMode)
    setError(null)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      if (mode === 'login') {
        await login(form.phone, form.password)
      } else {
        await register(form.name, form.phone, form.password)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card panel">
        <div className="brand" style={{ justifyContent: 'center', marginBottom: 6 }}>
          <span className="brand-mark" />DRIVELINE MOTORS
        </div>
        <p className="auth-subtitle">
          {mode === 'login' ? 'Log in to manage your garage and bookings.' : 'Create an account to track your vehicles.'}
        </p>

        <div className="auth-tabs">
          <button
            type="button"
            className={`auth-tab${mode === 'login' ? ' active' : ''}`}
            onClick={() => switchMode('login')}
          >
            Log in
          </button>
          <button
            type="button"
            className={`auth-tab${mode === 'register' ? ' active' : ''}`}
            onClick={() => switchMode('register')}
          >
            Sign up
          </button>
        </div>

        {error && <ErrorBanner>{error}</ErrorBanner>}

        <form onSubmit={handleSubmit}>
          {mode === 'register' && (
            <Field label="Full name">
              <input required value={form.name} onChange={(e) => set('name', e.target.value)} autoComplete="name" />
            </Field>
          )}
          <Field label="Mobile number">
            <input
              required type="tel" inputMode="tel" placeholder="e.g. 9876543210"
              value={form.phone} onChange={(e) => set('phone', e.target.value)}
              autoComplete="tel"
            />
          </Field>
          <Field label="Password">
            <input
              required type="password" minLength={mode === 'register' ? 6 : undefined}
              value={form.password} onChange={(e) => set('password', e.target.value)}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />
          </Field>

          <button type="submit" className="btn btn-block" disabled={submitting}>
            {submitting
              ? (mode === 'login' ? 'Logging in…' : 'Creating account…')
              : (mode === 'login' ? 'Log in' : 'Create account')}
          </button>
        </form>

        <div className="auth-divider"><span>or</span></div>

        <button type="button" className="btn-outline btn-block" onClick={continueAsGuest}>
          Continue as guest
        </button>
        <p className="auth-guest-note">
          Browse vehicles, use the EMI calculator, and book a service without an account.
          Your own garage and vehicle history need a free account to save against your phone number.
        </p>
      </div>
    </div>
  )
}
