import { useVehicleBluetooth } from '../../hooks/useVehicleBluetooth.js'

export default function BluetoothPanel({ onSaveReading }) {
  const { supported, connecting, connected, deviceName, error, readings, connect, disconnect } = useVehicleBluetooth()

  return (
    <div className="panel">
      <div className="coord" style={{ marginBottom: 14 }}>BLUETOOTH (OBD / BLE ADAPTER)</div>

      <div className="bt-note">
        Connects over the Web Bluetooth API — Chrome or Edge only (not Safari or Firefox),
        and only to adapters that use Bluetooth Low Energy. Most budget ELM327 dongles use
        classic Bluetooth and won't appear here at all. What a connected device actually
        streams depends entirely on its own protocol, so readings show as raw data you can
        choose to save — manual entry above is the reliable fallback for any vehicle.
      </div>

      <div className="bt-status">
        <span className={`bt-dot${connected ? ' connected' : ''}`} />
        {connected ? `Connected: ${deviceName}` : supported ? 'Not connected' : 'Not supported in this browser'}
      </div>

      {error && <div className="error-banner">{error}</div>}

      {!connected ? (
        <button className="btn btn-block" onClick={connect} disabled={!supported || connecting}>
          {connecting ? 'Connecting…' : 'Connect a Bluetooth device'}
        </button>
      ) : (
        <button className="btn-outline btn-block" onClick={disconnect}>Disconnect</button>
      )}

      {readings.length > 0 && (
        <div className="table-wrap" style={{ marginTop: 16 }}>
          <table>
            <thead><tr><th>Time</th><th>Characteristic</th><th>Raw data (hex)</th><th></th></tr></thead>
            <tbody>
              {readings.map((r) => (
                <tr key={r.id}>
                  <td>{new Date(r.timestamp).toLocaleTimeString()}</td>
                  <td>{r.characteristicUuid.slice(0, 8)}…</td>
                  <td>{r.hex}</td>
                  <td>
                    <button className="btn-outline btn-sm" onClick={() => onSaveReading(r)}>Save</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
