import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useGarageVehicles } from '../../hooks/useGarageVehicles.js'
import { garageApi } from '../../api/garage.api.js'
import { useToast } from '../../context/ToastContext.jsx'
import HealthLogForm from './HealthLogForm.jsx'
import BluetoothPanel from './BluetoothPanel.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import Spinner from '../../components/ui/Spinner.jsx'

export default function VehicleHealthPage() {
  const [searchParams] = useSearchParams()
  const { vehicles, loading } = useGarageVehicles()
  const { pushToast } = useToast()

  const [vehicleId, setVehicleId] = useState(searchParams.get('vehicleId') || '')
  const [logs, setLogs] = useState([])
  const [logsLoading, setLogsLoading] = useState(false)

  useEffect(() => {
    if (!vehicleId && vehicles.length > 0) setVehicleId(vehicles[0].id)
  }, [vehicles, vehicleId])

  function refreshLogs() {
    if (!vehicleId) return
    setLogsLoading(true)
    garageApi.listHealthLogs(vehicleId)
      .then((res) => setLogs(res.data))
      .catch(() => setLogs([]))
      .finally(() => setLogsLoading(false))
  }

  useEffect(() => { refreshLogs() }, [vehicleId]) // eslint-disable-line react-hooks/exhaustive-deps

  async function handleManualLog(payload) {
    await garageApi.addHealthLog(vehicleId, payload)
    pushToast('Health reading logged', 'success')
    refreshLogs()
  }

  async function handleSaveBluetoothReading(reading) {
    await garageApi.addHealthLog(vehicleId, { source: 'bluetooth', rawPayload: reading })
    pushToast('Bluetooth reading saved to vehicle history', 'success')
    refreshLogs()
  }

  const latest = logs[0]

  return (
    <>
      <div className="page-head">
        <span className="coord">05 / VEHICLE HEALTH</span>
        <h2>Health monitoring</h2>
        <p>Log readings by hand, or connect a compatible Bluetooth adapter to pull data straight from the vehicle.</p>
      </div>

      {loading && <div className="page-loading"><Spinner /></div>}

      {!loading && vehicles.length === 0 && (
        <EmptyState>Add a vehicle to your garage first, then come back here to track its health.</EmptyState>
      )}

      {!loading && vehicles.length > 0 && (
        <>
          <div className="panel" style={{ marginBottom: 20, maxWidth: 420 }}>
            <div className="field">
              <label>Vehicle</label>
              <select value={vehicleId} onChange={(e) => setVehicleId(e.target.value)}>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>{v.brand} {v.model} ({v.registrationNumber})</option>
                ))}
              </select>
            </div>
          </div>

          {latest && (
            <div className="health-readout">
              <div className="health-stat"><span className="coord">BATTERY</span><div className="num">{latest.battery_voltage ? `${latest.battery_voltage} V` : '—'}</div></div>
              <div className="health-stat"><span className="coord">FUEL</span><div className="num">{latest.fuel_level_percent ? `${latest.fuel_level_percent}%` : '—'}</div></div>
              <div className="health-stat"><span className="coord">ODOMETER</span><div className="num">{latest.odometer ? `${Number(latest.odometer).toLocaleString('en-IN')} km` : '—'}</div></div>
              <div className="health-stat"><span className="coord">ENGINE TEMP</span><div className="num">{latest.engine_temp_c ? `${latest.engine_temp_c}°C` : '—'}</div></div>
            </div>
          )}

          <div className="service-layout">
            <div className="panel">
              <div className="coord" style={{ marginBottom: 14 }}>LOG A READING MANUALLY</div>
              <HealthLogForm onSubmit={handleManualLog} />
            </div>
            <BluetoothPanel onSaveReading={handleSaveBluetoothReading} />
          </div>

          <div className="coord" style={{ margin: '24px 0 10px' }}>READING HISTORY</div>
          {logsLoading && <div className="grid-loading"><Spinner /></div>}
          {!logsLoading && logs.length === 0 && <EmptyState>No readings logged for this vehicle yet.</EmptyState>}
          {!logsLoading && logs.length > 0 && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>When</th><th>Source</th><th>Battery</th><th>Fuel</th><th>Odometer</th><th>Codes</th></tr></thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id}>
                      <td>{new Date(log.recorded_at).toLocaleString()}</td>
                      <td>{log.source}</td>
                      <td>{log.battery_voltage ? `${log.battery_voltage} V` : '—'}</td>
                      <td>{log.fuel_level_percent ? `${log.fuel_level_percent}%` : '—'}</td>
                      <td>{log.odometer ? `${Number(log.odometer).toLocaleString('en-IN')} km` : '—'}</td>
                      <td>{log.dtc_codes || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  )
}
