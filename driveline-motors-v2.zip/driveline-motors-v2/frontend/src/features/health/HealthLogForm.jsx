import { useState } from 'react'
import Field from '../../components/ui/Field.jsx'

const EMPTY = { batteryVoltage: '', fuelLevelPercent: '', odometer: '', engineTempC: '', dtcCodes: '' }

export default function HealthLogForm({ onSubmit }) {
  const [form, setForm] = useState(EMPTY)
  const [submitting, setSubmitting] = useState(false)

  function set(key, value) { setForm({ ...form, [key]: value }) }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await onSubmit({
        source: 'manual',
        batteryVoltage: form.batteryVoltage || null,
        fuelLevelPercent: form.fuelLevelPercent || null,
        odometer: form.odometer || null,
        engineTempC: form.engineTempC || null,
        dtcCodes: form.dtcCodes || null,
      })
      setForm(EMPTY)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="field-row">
        <Field label="Battery voltage (V)">
          <input type="number" step="0.1" placeholder="12.6" value={form.batteryVoltage} onChange={(e) => set('batteryVoltage', e.target.value)} />
        </Field>
        <Field label="Fuel level (%)">
          <input type="number" min="0" max="100" placeholder="75" value={form.fuelLevelPercent} onChange={(e) => set('fuelLevelPercent', e.target.value)} />
        </Field>
      </div>
      <div className="field-row">
        <Field label="Odometer (km)">
          <input type="number" min="0" value={form.odometer} onChange={(e) => set('odometer', e.target.value)} />
        </Field>
        <Field label="Engine temp (°C)">
          <input type="number" step="0.1" value={form.engineTempC} onChange={(e) => set('engineTempC', e.target.value)} />
        </Field>
      </div>
      <Field label="Trouble codes (optional)">
        <input placeholder="e.g. P0420" value={form.dtcCodes} onChange={(e) => set('dtcCodes', e.target.value)} />
      </Field>
      <button type="submit" className="btn btn-block" disabled={submitting}>
        {submitting ? 'Saving…' : 'Log reading'}
      </button>
    </form>
  )
}
