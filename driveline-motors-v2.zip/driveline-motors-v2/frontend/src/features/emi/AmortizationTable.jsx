import { money } from '../../lib/emi.js'

export default function AmortizationTable({ schedule }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>Month</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Balance</th></tr>
        </thead>
        <tbody>
          {schedule.map((row) => (
            <tr key={row.month}>
              <td>{row.month}</td>
              <td>{money(row.emi)}</td>
              <td>{money(row.principal)}</td>
              <td>{money(row.interest)}</td>
              <td>{money(row.balance)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
