import { money } from '../../lib/emi.js'
import AmortizationTable from './AmortizationTable.jsx'

export default function EMIResult({ result }) {
  return (
    <div>
      <div className="emi-result">
        <div className="result-box primary"><span className="coord">MONTHLY EMI</span><div className="num">{money(result.emi)}</div></div>
        <div className="result-box"><span className="coord">TOTAL INTEREST</span><div className="num">{money(result.totalInterest)}</div></div>
        <div className="result-box"><span className="coord">TOTAL PAYMENT</span><div className="num">{money(result.totalPayment)}</div></div>
      </div>
      <div className="coord" style={{ marginBottom: 8 }}>AMORTIZATION SCHEDULE</div>
      <AmortizationTable schedule={result.schedule} />
    </div>
  )
}
