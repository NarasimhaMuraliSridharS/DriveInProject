import Field from '../../components/ui/Field.jsx'

export default function EMIForm({ inputs, onChange }) {
  function set(key, value) {
    onChange({ ...inputs, [key]: value })
  }

  return (
    <div className="panel">
      <Field label="Vehicle price (₹)">
        <input type="number" min="0" step="1000" placeholder="e.g. 1200000" value={inputs.price} onChange={(e) => set('price', e.target.value)} />
      </Field>
      <Field label="Down payment (₹)">
        <input type="number" min="0" step="1000" placeholder="e.g. 200000" value={inputs.down} onChange={(e) => set('down', e.target.value)} />
      </Field>
      <div className="field-row">
        <Field label="Interest rate (% p.a.)">
          <input type="number" min="0" step="0.1" value={inputs.rate} onChange={(e) => set('rate', e.target.value)} />
        </Field>
        <Field label="Tenure (months)">
          <input type="number" min="1" step="1" value={inputs.months} onChange={(e) => set('months', e.target.value)} />
        </Field>
      </div>
    </div>
  )
}
