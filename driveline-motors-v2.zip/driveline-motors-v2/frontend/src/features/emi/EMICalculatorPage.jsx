import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import EMIForm from './EMIForm.jsx'
import EMIResult from './EMIResult.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import { computeEMI } from '../../lib/emi.js'

export default function EMICalculatorPage() {
  const location = useLocation()
  const [inputs, setInputs] = useState({ price: '', down: '', rate: '9.5', months: '36' })

  useEffect(() => {
    if (location.state?.prefillPrice) {
      setInputs((prev) => ({ ...prev, price: String(location.state.prefillPrice) }))
    }
  }, [location.state])

  const price = parseFloat(inputs.price) || 0
  const down = parseFloat(inputs.down) || 0
  const rate = parseFloat(inputs.rate) || 0
  const months = parseInt(inputs.months, 10) || 0
  const result = price > 0 && months > 0 ? computeEMI(price, down, rate, months) : null

  return (
    <>
      <div className="page-head">
        <span className="coord">02 / FINANCING</span>
        <h2>EMI calculator</h2>
        <p>Factor in a down payment and see the full month-by-month breakdown, not just the headline number.</p>
      </div>

      <div className="emi-layout">
        <EMIForm inputs={inputs} onChange={setInputs} />
        <div>
          {!result && <EmptyState>Enter a vehicle price and tenure to see your EMI.</EmptyState>}
          {result && <EMIResult result={result} />}
        </div>
      </div>
    </>
  )
}
