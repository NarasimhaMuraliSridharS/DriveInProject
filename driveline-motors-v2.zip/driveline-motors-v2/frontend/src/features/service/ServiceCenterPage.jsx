import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { useBookings } from '../../hooks/useBookings.js'
import { useVehicles } from '../../hooks/useVehicles.js'
import { bookingsApi } from '../../api/bookings.api.js'
import { useToast } from '../../context/ToastContext.jsx'
import BookingForm from './BookingForm.jsx'
import BookingList from './BookingList.jsx'
import { SERVICE_TYPES, TIME_SLOTS } from '../../constants/index.js'

const EMPTY_FORM = {
  name: '', phone: '', vehicleId: '',
  serviceType: SERVICE_TYPES[0], date: '', slot: TIME_SLOTS[0], notes: '',
}

export default function ServiceCenterPage() {
  const location = useLocation()
  const { pushToast } = useToast()
  const { vehicles } = useVehicles({})
  const { bookings, error, refresh } = useBookings()

  const [form, setForm] = useState(EMPTY_FORM)
  const [submitError, setSubmitError] = useState(null)

  useEffect(() => {
    if (location.state?.prefillVehicle) {
      setForm((f) => ({ ...f, vehicleId: location.state.prefillVehicle.id }))
    }
  }, [location.state])

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitError(null)
    try {
      await bookingsApi.create({ ...form, vehicleId: form.vehicleId || null })
      pushToast("Booking request received — we'll confirm your slot shortly.", 'success')
      setForm(EMPTY_FORM)
      refresh()
    } catch (err) {
      setSubmitError(err.message)
    }
  }

  async function handleCancel(id) {
    try {
      await bookingsApi.cancel(id)
      pushToast('Booking cancelled', 'info')
      refresh()
    } catch (err) {
      pushToast(err.message, 'error')
    }
  }

  return (
    <>
      <div className="page-head">
        <span className="coord">03 / SERVICE CENTER</span>
        <h2>Book a service slot</h2>
        <p>From an oil change to a full service, for cars and bikes alike.</p>
      </div>

      <div className="service-layout">
        <BookingForm form={form} onChange={setForm} onSubmit={handleSubmit} vehicles={vehicles} error={submitError} />
        <BookingList bookings={bookings} error={error} onCancel={handleCancel} />
      </div>
    </>
  )
}
