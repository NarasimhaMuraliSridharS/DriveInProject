import BookingItem from './BookingItem.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'

export default function BookingList({ bookings, error, onCancel }) {
  return (
    <div>
      <div className="coord" style={{ marginBottom: 14 }}>ALL BOOKINGS</div>
      {error && <ErrorBanner>{error}</ErrorBanner>}
      {bookings.length === 0 && <EmptyState>No service bookings yet.</EmptyState>}
      {[...bookings].reverse().map((b) => (
        <BookingItem key={b.id} booking={b} onCancel={() => onCancel(b.id)} />
      ))}
    </div>
  )
}
