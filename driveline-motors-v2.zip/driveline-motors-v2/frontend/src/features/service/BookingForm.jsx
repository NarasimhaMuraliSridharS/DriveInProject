import Field from '../../components/ui/Field.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'
import { SERVICE_TYPES, TIME_SLOTS } from '../../constants/index.js'

export default function BookingForm({ form, onChange, onSubmit, vehicles, error }) {
  const today = new Date().toISOString().slice(0, 10)

  function set(key, value) {
    onChange({ ...form, [key]: value })
  }

  return (
    <form className="panel" onSubmit={onSubmit}>
      {error && <ErrorBanner>{error}</ErrorBanner>}
      <Field label="Full name">
        <input type="text" required value={form.name} onChange={(e) => set('name', e.target.value)} />
      </Field>
      <Field label="Phone number">
        <input type="tel" required value={form.phone} onChange={(e) => set('phone', e.target.value)} />
      </Field>
      <Field label="Vehicle">
        <select value={form.vehicleId} onChange={(e) => set('vehicleId', e.target.value)}>
          <option value="">Not listed / other</option>
          {vehicles.map((v) => (
            <option key={v.id} value={v.id}>{v.brand} {v.model} ({v.condition})</option>
          ))}
        </select>
      </Field>
      <Field label="Service type">
        <select value={form.serviceType} onChange={(e) => set('serviceType', e.target.value)}>
          {SERVICE_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>
      <div className="field-row">
        <Field label="Preferred date">
          <input type="date" required min={today} value={form.date} onChange={(e) => set('date', e.target.value)} />
        </Field>
        <Field label="Preferred time">
          <select value={form.slot} onChange={(e) => set('slot', e.target.value)}>
            {TIME_SLOTS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Notes (optional)">
        <textarea placeholder="Anything we should know before you arrive" value={form.notes} onChange={(e) => set('notes', e.target.value)} />
      </Field>
      <button type="submit" className="btn btn-block">Book service</button>
    </form>
  )
}
