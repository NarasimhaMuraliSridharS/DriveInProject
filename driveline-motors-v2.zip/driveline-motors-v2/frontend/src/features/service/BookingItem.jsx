export default function BookingItem({ booking, onCancel }) {
  const cancelled = booking.status === 'cancelled'

  return (
    <div className={`booking-item${cancelled ? ' cancelled' : ''}`}>
      <div className="top-row">
        <div>
          <h4>{booking.service_type}</h4>
          <div className="meta" style={{ fontSize: 13, color: 'var(--ink-dim)' }}>
            {booking.vehicle_label || 'Vehicle not listed'}
          </div>
        </div>
        {!cancelled
          ? <button className="btn-outline btn-sm" onClick={onCancel}>Cancel</button>
          : <span className="tag">Cancelled</span>}
      </div>
      <span className="coord">{booking.date} · {booking.slot} · {booking.name} · {booking.phone}</span>
    </div>
  )
}
