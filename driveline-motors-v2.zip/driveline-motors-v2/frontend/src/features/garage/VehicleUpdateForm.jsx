import { useState } from 'react'
import Field from '../../components/ui/Field.jsx'

export default function VehicleUpdateForm({ vehicle, onSubmit }) {
  const [form, setForm] = useState({
    currentOdometer: vehicle.currentOdometer,
    insuranceExpiry: vehicle.insuranceExpiry?.slice(0, 10) || '',
    fitnessExpiry: vehicle.fitnessExpiry?.slice(0, 10) || '',
  })
  const [submitting, setSubmitting] = useState(false)

  function set(key, value) { setForm({ ...form, [key]: value }) }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await onSubmit(form)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Field label="Current odometer (km)">
        <input type="number" min="0" value={form.currentOdometer} onChange={(e) => set('currentOdometer', e.target.value)} />
      </Field>
      <div className="field-row">
        <Field label="Insurance expiry">
          <input type="date" value={form.insuranceExpiry} onChange={(e) => set('insuranceExpiry', e.target.value)} />
        </Field>
        <Field label="RC fitness expiry">
          <input type="date" value={form.fitnessExpiry} onChange={(e) => set('fitnessExpiry', e.target.value)} />
        </Field>
      </div>
      <button type="submit" className="btn-outline btn-block" disabled={submitting}>
        {submitting ? 'Saving…' : 'Save changes'}
      </button>
    </form>
  )
}
