import { money } from '../../lib/emi.js'
import EmptyState from '../../components/ui/EmptyState.jsx'

export default function ServiceRecordList({ records, onRemove }) {
  if (records.length === 0) return <EmptyState>No service records logged yet.</EmptyState>

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>Date</th><th>Odometer</th><th>Type</th><th>Cost</th><th>Notes</th><th></th></tr>
        </thead>
        <tbody>
          {records.map((r) => (
            <tr key={r.id}>
              <td>{r.service_date?.slice(0, 10)}</td>
              <td>{r.odometer.toLocaleString('en-IN')} km</td>
              <td>{r.service_type}</td>
              <td>{r.cost != null ? money(Number(r.cost)) : '—'}</td>
              <td style={{ whiteSpace: 'normal', maxWidth: 220 }}>{r.notes || '—'}</td>
              <td><button className="btn-outline btn-sm" onClick={() => onRemove(r.id)}>Remove</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
