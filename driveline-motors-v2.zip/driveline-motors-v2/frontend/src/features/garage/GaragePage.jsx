import { useGarageVehicles } from '../../hooks/useGarageVehicles.js'
import { garageApi } from '../../api/garage.api.js'
import { useToast } from '../../context/ToastContext.jsx'
import VehicleForm from './VehicleForm.jsx'
import GarageVehicleCard from './GarageVehicleCard.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'
import Spinner from '../../components/ui/Spinner.jsx'
import { useState } from 'react'

export default function GaragePage() {
  const { vehicles, loading, error, refresh } = useGarageVehicles()
  const { pushToast } = useToast()
  const [formError, setFormError] = useState(null)

  async function handleCreate(form) {
    setFormError(null)
    try {
      await garageApi.createVehicle({
        ...form,
        purchaseDate: form.purchaseDate || null,
        currentOdometer: form.currentOdometer || 0,
        serviceIntervalKm: form.serviceIntervalKm || undefined,
        serviceIntervalMonths: form.serviceIntervalMonths || undefined,
      })
      pushToast('Vehicle added to your garage', 'success')
      refresh()
    } catch (err) {
      setFormError(err.message)
      throw err
    }
  }

  const overdueCount = vehicles.filter((v) => v.alertLevel === 'overdue').length
  const warningCount = vehicles.filter((v) => v.alertLevel === 'warning').length

  return (
    <>
      <div className="page-head">
        <span className="coord">04 / MY GARAGE</span>
        <h2>Your registered vehicles</h2>
        <p>Track insurance, RC fitness, and service due dates for every car and bike you own.</p>
      </div>

      <div className="garage-layout">
        <VehicleForm onSubmit={handleCreate} error={formError} />

        <div>
          {!loading && vehicles.length > 0 && (
            <div className="result-count">
              {vehicles.length} vehicle{vehicles.length === 1 ? '' : 's'}
              {overdueCount > 0 && ` · ${overdueCount} need${overdueCount === 1 ? 's' : ''} action`}
              {warningCount > 0 && ` · ${warningCount} due soon`}
            </div>
          )}
          {error && <ErrorBanner>Couldn't load your garage: {error}</ErrorBanner>}
          {loading && <div className="grid-loading"><Spinner /></div>}
          {!loading && vehicles.length === 0 && (
            <EmptyState>No vehicles yet — add your first one to start tracking alerts.</EmptyState>
          )}
          {!loading && vehicles.map((v) => <GarageVehicleCard key={v.id} vehicle={v} />)}
        </div>
      </div>
    </>
  )
}
