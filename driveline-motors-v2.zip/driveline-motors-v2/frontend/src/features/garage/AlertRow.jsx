export default function AlertRow({ alert }) {
  return (
    <div className="garage-alert-row">
      <span className={`alert-dot ${alert.level}`} />
      <span>{alert.message}</span>
    </div>
  )
}
