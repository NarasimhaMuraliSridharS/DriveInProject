import { useState } from 'react'
import Field from '../../components/ui/Field.jsx'
import { SERVICE_TYPES } from '../../constants/index.js'

const EMPTY = { serviceDate: '', odometer: '', serviceType: SERVICE_TYPES[0], cost: '', notes: '' }

export default function ServiceRecordForm({ onSubmit }) {
  const [form, setForm] = useState(EMPTY)
  const [submitting, setSubmitting] = useState(false)

  function set(key, value) { setForm({ ...form, [key]: value }) }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await onSubmit({ ...form, cost: form.cost || null })
      setForm(EMPTY)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="field-row">
        <Field label="Service date">
          <input required type="date" value={form.serviceDate} onChange={(e) => set('serviceDate', e.target.value)} />
        </Field>
        <Field label="Odometer (km)">
          <input required type="number" min="0" value={form.odometer} onChange={(e) => set('odometer', e.target.value)} />
        </Field>
      </div>
      <Field label="Service type">
        <select value={form.serviceType} onChange={(e) => set('serviceType', e.target.value)}>
          {SERVICE_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </Field>
      <Field label="Cost (₹, optional)">
        <input type="number" min="0" value={form.cost} onChange={(e) => set('cost', e.target.value)} />
      </Field>
      <Field label="Notes (optional)">
        <textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} />
      </Field>
      <button type="submit" className="btn btn-block" disabled={submitting}>
        {submitting ? 'Logging…' : 'Log service record'}
      </button>
    </form>
  )
}
