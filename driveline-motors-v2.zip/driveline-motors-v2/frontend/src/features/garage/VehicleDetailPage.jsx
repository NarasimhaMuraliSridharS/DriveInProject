import { Link, useNavigate, useParams } from 'react-router-dom'
import { useGarageVehicle } from '../../hooks/useGarageVehicle.js'
import { garageApi } from '../../api/garage.api.js'
import { useToast } from '../../context/ToastContext.jsx'
import AlertRow from './AlertRow.jsx'
import ServiceRecordForm from './ServiceRecordForm.jsx'
import ServiceRecordList from './ServiceRecordList.jsx'
import VehicleUpdateForm from './VehicleUpdateForm.jsx'
import Spinner from '../../components/ui/Spinner.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'

export default function VehicleDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { pushToast } = useToast()
  const { vehicle, loading, error, refresh } = useGarageVehicle(id)

  async function handleAddRecord(payload) {
    await garageApi.addServiceRecord(id, payload)
    pushToast('Service record logged', 'success')
    refresh()
  }

  async function handleRemoveRecord(recordId) {
    await garageApi.removeServiceRecord(recordId)
    pushToast('Service record removed', 'info')
    refresh()
  }

  async function handleUpdate(fields) {
    await garageApi.updateVehicle(id, fields)
    pushToast('Vehicle updated', 'success')
    refresh()
  }

  async function handleDelete() {
    if (!confirm('Remove this vehicle and all of its history? This cannot be undone.')) return
    await garageApi.removeVehicle(id)
    pushToast('Vehicle removed from garage', 'info')
    navigate('/garage')
  }

  if (loading) return <div className="page-loading"><Spinner /></div>
  if (error) return <ErrorBanner>Couldn't load this vehicle: {error}</ErrorBanner>
  if (!vehicle) return null

  return (
    <>
      <div className="page-head">
        <span className="coord">04 / MY GARAGE</span>
        <h2>{vehicle.brand} {vehicle.model}</h2>
        <p>{vehicle.registrationNumber} · Owner: {vehicle.ownerName} · {vehicle.ownerPhone}</p>
      </div>

      <div className="garage-layout">
        <div>
          <div className="panel">
            <div className="coord" style={{ marginBottom: 14 }}>STATUS</div>
            {vehicle.alerts.map((alert) => <AlertRow key={alert.type} alert={alert} />)}
          </div>
          <div className="panel">
            <div className="coord" style={{ marginBottom: 14 }}>UPDATE ODOMETER / EXPIRY</div>
            <VehicleUpdateForm vehicle={vehicle} onSubmit={handleUpdate} />
          </div>
          <div className="panel">
            <button className="btn-danger btn-outline btn-block" onClick={handleDelete}>Remove vehicle</button>
          </div>
        </div>

        <div>
          <div className="panel">
            <div className="coord" style={{ marginBottom: 14 }}>LOG A SERVICE</div>
            <ServiceRecordForm onSubmit={handleAddRecord} />
          </div>
          <div className="coord" style={{ margin: '20px 0 10px' }}>SERVICE HISTORY</div>
          <ServiceRecordList records={vehicle.serviceRecords || []} onRemove={handleRemoveRecord} />
          <div style={{ marginTop: 20 }}>
            <Link to={`/health?vehicleId=${vehicle.id}`} className="btn-outline" style={{ textDecoration: 'none' }}>
              Open vehicle health & Bluetooth →
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
