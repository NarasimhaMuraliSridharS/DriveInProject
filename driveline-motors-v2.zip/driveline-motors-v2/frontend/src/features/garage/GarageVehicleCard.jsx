import { Link } from 'react-router-dom'
import AlertRow from './AlertRow.jsx'

export default function GarageVehicleCard({ vehicle }) {
  return (
    <Link to={`/garage/${vehicle.id}`} className={`garage-vcard level-${vehicle.alertLevel}`} style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
      <div className="garage-vcard-head">
        <div>
          <h3>{vehicle.brand} {vehicle.model}</h3>
          <span className="reg">{vehicle.registrationNumber} · {vehicle.type === 'car' ? 'Car' : 'Bike'}</span>
        </div>
        <span className={`tag level-${vehicle.alertLevel}`}>
          {vehicle.alertLevel === 'ok' ? 'All clear' : vehicle.alertLevel === 'warning' ? 'Due soon' : 'Action needed'}
        </span>
      </div>
      {vehicle.alerts.map((alert) => <AlertRow key={alert.type} alert={alert} />)}
    </Link>
  )
}
