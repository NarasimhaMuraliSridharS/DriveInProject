import { useState } from 'react'
import Field from '../../components/ui/Field.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'
import { VEHICLE_TYPES } from '../../constants/index.js'

const EMPTY = {
  ownerName: '', ownerPhone: '', type: 'car', brand: '', model: '',
  registrationNumber: '', purchaseDate: '', insuranceExpiry: '', fitnessExpiry: '',
  currentOdometer: '0', serviceIntervalKm: '', serviceIntervalMonths: '',
}

export default function VehicleForm({ onSubmit, error }) {
  const [form, setForm] = useState(EMPTY)
  const [submitting, setSubmitting] = useState(false)

  function set(key, value) { setForm({ ...form, [key]: value }) }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await onSubmit(form)
      setForm(EMPTY)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form className="panel" onSubmit={handleSubmit}>
      <div className="coord" style={{ marginBottom: 14 }}>ADD A VEHICLE</div>
      {error && <ErrorBanner>{error}</ErrorBanner>}
      <Field label="Owner name">
        <input required value={form.ownerName} onChange={(e) => set('ownerName', e.target.value)} />
      </Field>
      <Field label="Owner phone">
        <input required type="tel" value={form.ownerPhone} onChange={(e) => set('ownerPhone', e.target.value)} />
      </Field>
      <div className="field-row">
        <Field label="Type">
          <select value={form.type} onChange={(e) => set('type', e.target.value)}>
            {VEHICLE_TYPES.map((t) => <option key={t} value={t}>{t === 'car' ? 'Car' : 'Bike'}</option>)}
          </select>
        </Field>
        <Field label="Registration number">
          <input required placeholder="e.g. TN09AB1234" value={form.registrationNumber} onChange={(e) => set('registrationNumber', e.target.value.toUpperCase())} />
        </Field>
      </div>
      <div className="field-row">
        <Field label="Brand">
          <input required value={form.brand} onChange={(e) => set('brand', e.target.value)} />
        </Field>
        <Field label="Model">
          <input required value={form.model} onChange={(e) => set('model', e.target.value)} />
        </Field>
      </div>
      <Field label="Current odometer (km)">
        <input type="number" min="0" value={form.currentOdometer} onChange={(e) => set('currentOdometer', e.target.value)} />
      </Field>
      <div className="field-row">
        <Field label="Insurance expiry">
          <input required type="date" value={form.insuranceExpiry} onChange={(e) => set('insuranceExpiry', e.target.value)} />
        </Field>
        <Field label="RC fitness expiry">
          <input required type="date" value={form.fitnessExpiry} onChange={(e) => set('fitnessExpiry', e.target.value)} />
        </Field>
      </div>
      <div className="field-row">
        <Field label="Service interval (km, optional)">
          <input type="number" min="0" placeholder="5000" value={form.serviceIntervalKm} onChange={(e) => set('serviceIntervalKm', e.target.value)} />
        </Field>
        <Field label="Service interval (months, optional)">
          <input type="number" min="0" placeholder="6" value={form.serviceIntervalMonths} onChange={(e) => set('serviceIntervalMonths', e.target.value)} />
        </Field>
      </div>
      <button type="submit" className="btn btn-block" disabled={submitting}>
        {submitting ? 'Adding…' : 'Add to garage'}
      </button>
    </form>
  )
}
