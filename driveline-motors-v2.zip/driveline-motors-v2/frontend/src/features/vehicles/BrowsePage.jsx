import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useVehicles } from '../../hooks/useVehicles.js'
import { useBrands } from '../../hooks/useBrands.js'
import { useDebouncedValue } from '../../hooks/useDebouncedValue.js'
import { useVehicleMatch } from '../../hooks/useVehicleMatch.js'
import VehicleFilters from './VehicleFilters.jsx'
import MatchPreferencePanel from './MatchPreferencePanel.jsx'
import VehicleGrid from './VehicleGrid.jsx'
import ErrorBanner from '../../components/ui/ErrorBanner.jsx'

const DEFAULT_FILTERS = { type: 'all', condition: 'all', fuel: 'all', brand: 'all', maxPrice: '' }

export default function BrowsePage() {
  const navigate = useNavigate()
  const brands = useBrands()

  const [filters, setFilters] = useState(DEFAULT_FILTERS)
  const debouncedFilters = useDebouncedValue(filters, 250)
  const { vehicles, loading, error } = useVehicles(debouncedFilters)

  const [preference, setPreference] = useState(null)
  const { results: matched, loading: matchLoading } = useVehicleMatch(preference)

  const list = preference ? matched : vehicles
  const isLoading = preference ? matchLoading : loading
  const topMatchIds = new Set(preference ? matched.slice(0, 3).map((v) => v.id) : [])

  function goToEMI(vehicle) {
    navigate('/emi', { state: { prefillPrice: vehicle.price } })
  }

  function goToService(vehicle) {
    navigate('/service', { state: { prefillVehicle: vehicle } })
  }

  return (
    <>
      <div className="page-head">
        <span className="coord">01 / INVENTORY</span>
        <h2>Browse cars &amp; bikes</h2>
        <p>New and used vehicles, filtered and ranked to fit what you're actually looking for.</p>
      </div>

      <div className="browse-layout">
        <div>
          <VehicleFilters filters={filters} onChange={setFilters} brands={brands} />
          <MatchPreferencePanel active={!!preference} onApply={setPreference} onClear={() => setPreference(null)} />
        </div>
        <div>
          {error && <ErrorBanner>Couldn't load vehicles: {error}</ErrorBanner>}
          <VehicleGrid
            vehicles={list}
            loading={isLoading}
            topMatchIds={topMatchIds}
            rankedByMatch={!!preference}
            onCalcEMI={goToEMI}
            onBookService={goToService}
          />
        </div>
      </div>
    </>
  )
}
