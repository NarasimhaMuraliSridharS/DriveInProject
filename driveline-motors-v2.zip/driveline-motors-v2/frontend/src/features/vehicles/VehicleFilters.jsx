import Field from '../../components/ui/Field.jsx'
import { CONDITIONS, FUEL_TYPES, VEHICLE_TYPES } from '../../constants/index.js'

export default function VehicleFilters({ filters, onChange, brands }) {
  function set(key, value) {
    onChange({ ...filters, [key]: value })
  }

  return (
    <div className="panel">
      <div className="coord" style={{ marginBottom: 14 }}>FILTERS</div>
      <Field label="Type">
        <select value={filters.type} onChange={(e) => set('type', e.target.value)}>
          <option value="all">All</option>
          {VEHICLE_TYPES.map((t) => (
            <option key={t} value={t}>{t === 'car' ? 'Cars' : 'Bikes'}</option>
          ))}
        </select>
      </Field>
      <Field label="Condition">
        <select value={filters.condition} onChange={(e) => set('condition', e.target.value)}>
          <option value="all">All</option>
          {CONDITIONS.map((c) => (
            <option key={c} value={c}>{c === 'new' ? 'New' : 'Used'}</option>
          ))}
        </select>
      </Field>
      <Field label="Fuel">
        <select value={filters.fuel} onChange={(e) => set('fuel', e.target.value)}>
          <option value="all">All</option>
          {FUEL_TYPES.map((f) => <option key={f} value={f}>{f}</option>)}
        </select>
      </Field>
      <Field label="Brand">
        <select value={filters.brand} onChange={(e) => set('brand', e.target.value)}>
          <option value="all">All</option>
          {brands.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
      </Field>
      <Field label="Max budget (₹)">
        <input
          type="number" min="0" step="1000" placeholder="e.g. 500000"
          value={filters.maxPrice}
          onChange={(e) => set('maxPrice', e.target.value)}
        />
      </Field>
    </div>
  )
}
