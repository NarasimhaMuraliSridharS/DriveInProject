import { useState } from 'react'
import Field from '../../components/ui/Field.jsx'
import { FUEL_TYPES, VEHICLE_TYPES } from '../../constants/index.js'

const EMPTY_DRAFT = { budget: '', type: 'all', fuel: 'all' }

export default function MatchPreferencePanel({ active, onApply, onClear }) {
  const [draft, setDraft] = useState(EMPTY_DRAFT)

  return (
    <div className="panel">
      <div className="coord" style={{ marginBottom: 14 }}>FIND YOUR MATCH</div>
      <p style={{ fontSize: 13, color: 'var(--ink-dim)', margin: '0 0 14px' }}>
        Tell us your budget and we'll rank listings by fit.
      </p>
      <Field label="Your budget (₹)">
        <input
          type="number" min="0" step="1000" placeholder="e.g. 700000"
          value={draft.budget}
          onChange={(e) => setDraft({ ...draft, budget: e.target.value })}
        />
      </Field>
      <Field label="Prefer">
        <select value={draft.type} onChange={(e) => setDraft({ ...draft, type: e.target.value })}>
          <option value="all">No preference</option>
          {VEHICLE_TYPES.map((t) => <option key={t} value={t}>{t === 'car' ? 'Car' : 'Bike'}</option>)}
        </select>
      </Field>
      <Field label="Fuel">
        <select value={draft.fuel} onChange={(e) => setDraft({ ...draft, fuel: e.target.value })}>
          <option value="all">No preference</option>
          {FUEL_TYPES.map((f) => <option key={f} value={f}>{f}</option>)}
        </select>
      </Field>
      <button className="btn btn-block" onClick={() => onApply(draft)}>Rank by match</button>
      {active && (
        <button
          className="btn-outline btn-block" style={{ marginTop: 8 }}
          onClick={() => { onClear(); setDraft(EMPTY_DRAFT) }}
        >
          Clear preference
        </button>
      )}
    </div>
  )
}
