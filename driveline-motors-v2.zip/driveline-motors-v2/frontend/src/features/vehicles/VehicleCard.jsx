import { money } from '../../lib/emi.js'
import { formatKm } from '../../lib/format.js'

export default function VehicleCard({ vehicle, highlighted, onCalcEMI, onBookService }) {
  const km = formatKm(vehicle.km)

  return (
    <div className={`vcard${highlighted ? ' match' : ''}`}>
      {highlighted && <span className="vcard-badge">Best match</span>}
      <div className="vcard-tags">
        <span className={`tag${vehicle.condition === 'new' ? ' new' : ''}`}>
          {vehicle.condition === 'new' ? 'New' : 'Used'}
        </span>
        <span className="tag">{vehicle.fuel}</span>
        <span className="tag">{vehicle.body}</span>
      </div>
      <h3>{vehicle.brand} {vehicle.model}</h3>
      <div className="meta">{vehicle.year}{km ? ` · ${km}` : ''}</div>
      <div className="price">{money(vehicle.price)}</div>
      <div className="vcard-actions">
        <button className="btn-outline btn-sm" onClick={onCalcEMI}>Calc EMI</button>
        <button className="btn-outline btn-sm" onClick={onBookService}>Book service</button>
      </div>
    </div>
  )
}
