import VehicleCard from './VehicleCard.jsx'
import EmptyState from '../../components/ui/EmptyState.jsx'
import Spinner from '../../components/ui/Spinner.jsx'

export default function VehicleGrid({ vehicles, loading, topMatchIds, rankedByMatch, onCalcEMI, onBookService }) {
  return (
    <>
      <div className="result-count">
        {loading
          ? 'Loading…'
          : `${vehicles.length} vehicle${vehicles.length === 1 ? '' : 's'} found${rankedByMatch ? ' · ranked by match' : ''}`}
      </div>

      {loading && <div className="grid-loading"><Spinner /></div>}
      {!loading && vehicles.length === 0 && <EmptyState>No vehicles match these filters.</EmptyState>}

      <div className="grid">
        {!loading && vehicles.map((v) => (
          <VehicleCard
            key={v.id}
            vehicle={v}
            highlighted={topMatchIds.has(v.id)}
            onCalcEMI={() => onCalcEMI(v)}
            onBookService={() => onBookService(v)}
          />
        ))}
      </div>
    </>
  )
}
