export default function Footer() {
  return (
    <footer>
      <div className="wrap footer-inner">
        <span className="coord">DRIVELINE MOTORS</span>
        <span className="coord">REACT + NODE/EXPRESS + POSTGRESQL</span>
      </div>
    </footer>
  )
}
