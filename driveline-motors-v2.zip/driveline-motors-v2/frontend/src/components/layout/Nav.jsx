import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { useTheme } from '../../context/ThemeContext.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useGarageAlerts } from '../../hooks/useGarageAlerts.js'

const LINKS = [
  { to: '/', label: 'Browse vehicles', end: true },
  { to: '/emi', label: 'EMI calculator' },
  { to: '/service', label: 'Service center' },
  { to: '/garage', label: 'My garage' },
  { to: '/health', label: 'Vehicle health' },
]

export default function Nav() {
  const { theme, toggleTheme } = useTheme()
  const { status, user, logout } = useAuth()
  const { alerts } = useGarageAlerts()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="topbar">
      <div className="wrap topbar-inner" style={{ position: 'relative' }}>
        <div className="brand"><span className="brand-mark" />DRIVELINE MOTORS</div>

        <nav className={`tabs${menuOpen ? ' open' : ''}`} onClick={() => setMenuOpen(false)}>
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) => `tab-btn${isActive ? ' active' : ''}`}
            >
              {link.label}
            </NavLink>
          ))}
          {/* Shown only inside the mobile dropdown (hidden on wider screens
              by CSS) so the account action is reachable from the hamburger
              menu without duplicating it next to the desktop nav links. */}
          <div className="tabs-account">
            <span className="coord">{status === 'guest' ? 'BROWSING AS GUEST' : `SIGNED IN · ${user?.name}`}</span>
            <button type="button" className="tab-btn" onClick={logout}>
              {status === 'guest' ? 'Log in' : 'Log out'}
            </button>
          </div>
        </nav>

        <div className="nav-right">
          <button type="button" className="account-chip" onClick={logout} title={status === 'guest' ? 'Browsing as guest — click to log in' : `${user?.name} — click to log out`}>
            {status === 'guest' ? '👤 Guest' : `👤 ${user?.name?.split(' ')[0]}`}
          </button>
          <NavLink to="/garage" className="icon-btn" title="Alerts" aria-label="Vehicle alerts">
            🔔
            {alerts.length > 0 && <span className="alert-badge">{alerts.length > 9 ? '9+' : alerts.length}</span>}
          </NavLink>
          <button
            className="icon-btn" onClick={toggleTheme}
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle color theme"
          >
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
          <button
            className="menu-toggle" onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle navigation menu" aria-expanded={menuOpen}
          >
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>
      </div>
    </div>
  )
}
