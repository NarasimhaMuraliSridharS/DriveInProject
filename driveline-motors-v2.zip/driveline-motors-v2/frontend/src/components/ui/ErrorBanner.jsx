export default function ErrorBanner({ children }) {
  return <div className="error-banner" role="alert">{children}</div>
}
