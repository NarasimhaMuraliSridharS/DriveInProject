import Layout from './components/layout/Layout.jsx'
import AppRoutes from './routes/AppRoutes.jsx'
import AuthPage from './features/auth/AuthPage.jsx'
import Spinner from './components/ui/Spinner.jsx'
import { useAuth } from './context/AuthContext.jsx'

export default function App() {
  const { status } = useAuth()

  if (status === 'loading') {
    return <div className="page-loading"><Spinner /></div>
  }

  if (status === 'unauthenticated') {
    return <AuthPage />
  }

  // 'authenticated' and 'guest' both reach the real app - every route and
  // API call already supports guests, so there's nothing further to gate.
  return (
    <Layout>
      <AppRoutes />
    </Layout>
  )
}
