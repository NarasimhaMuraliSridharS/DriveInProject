import { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Spinner from '../components/ui/Spinner.jsx'

// Code-split each page so the initial bundle only pays for the page
// someone actually lands on - relevant now that this is a real
// multi-route website rather than a single tab-switching bundle.
const BrowsePage = lazy(() => import('../features/vehicles/BrowsePage.jsx'))
const EMICalculatorPage = lazy(() => import('../features/emi/EMICalculatorPage.jsx'))
const ServiceCenterPage = lazy(() => import('../features/service/ServiceCenterPage.jsx'))
const GaragePage = lazy(() => import('../features/garage/GaragePage.jsx'))
const VehicleDetailPage = lazy(() => import('../features/garage/VehicleDetailPage.jsx'))
const VehicleHealthPage = lazy(() => import('../features/health/VehicleHealthPage.jsx'))

export default function AppRoutes() {
  return (
    <Suspense fallback={<div className="page-loading"><Spinner /></div>}>
      <Routes>
        <Route path="/" element={<BrowsePage />} />
        <Route path="/emi" element={<EMICalculatorPage />} />
        <Route path="/service" element={<ServiceCenterPage />} />
        <Route path="/garage" element={<GaragePage />} />
        <Route path="/garage/:id" element={<VehicleDetailPage />} />
        <Route path="/health" element={<VehicleHealthPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
