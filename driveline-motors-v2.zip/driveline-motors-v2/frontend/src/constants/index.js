// Mirrors backend/src/constants/index.js. Kept as plain arrays (not
// fetched from the API) so dropdowns render instantly with no loading
// state - these values change about as often as the codebase does.

export const VEHICLE_TYPES = ['car', 'bike']
export const CONDITIONS = ['new', 'used']
export const FUEL_TYPES = ['Petrol', 'Diesel', 'Electric', 'CNG']

export const SERVICE_TYPES = [
  'General service',
  'Oil change',
  'Brake inspection',
  'Battery check',
  'Full service',
  'Bike tuning',
  'Denting & painting',
]

export const TIME_SLOTS = [
  '9:00 - 11:00 AM',
  '11:00 AM - 1:00 PM',
  '1:00 - 3:00 PM',
  '3:00 - 5:00 PM',
  '5:00 - 7:00 PM',
]
