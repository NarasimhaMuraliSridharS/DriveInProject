# Driveline Motors — web client

React + Vite, routed with react-router-dom.

```
src/
  api/          fetch wrapper + one module per resource (vehicles, bookings, garage)
  constants/    mirrors of the backend's enums (service types, slots, fuel types)
  hooks/        data-fetching hooks (useVehicles, useBrands, useVehicleMatch, useBookings,
                 useGarageVehicles, useGarageVehicle, useGarageAlerts, useVehicleBluetooth)
  context/      ToastContext (notifications), ThemeContext (light/dark, persisted),
                 AuthContext (login/register/guest, token persistence, 401 auto-logout)
  components/
    layout/     Nav (hamburger menu + theme toggle + alert bell + account chip), Footer, Layout
    ui/         small shared pieces (Field, Spinner, EmptyState, ErrorBanner)
  features/
    auth/       AuthPage — login/register toggle + "Continue as guest"
    vehicles/   BrowsePage + filters, match panel, grid, card
    emi/        EMICalculatorPage + form, result, amortization table
    service/    ServiceCenterPage + booking form, list, item
    garage/     GaragePage, VehicleDetailPage, vehicle form, service record log, alert rows
    health/     VehicleHealthPage, manual reading form, BluetoothPanel (Web Bluetooth)
  routes/       AppRoutes.jsx — route definitions, lazy-loaded per page
  lib/          emi.js (EMI math), format.js
  styles/       index.css (single stylesheet, CSS variables for both themes, responsive)
```

## Routes
`/` browse · `/emi` EMI calculator · `/service` service bookings ·
`/garage` your registered vehicles · `/garage/:id` vehicle detail, service history,
odometer/expiry editing · `/health` manual + Bluetooth health logging

## Authentication (`context/AuthContext.jsx`, `features/auth/AuthPage.jsx`)

Four states drive what the app shows: `loading` (checking a saved token on first
load), `authenticated`, `guest`, and `unauthenticated` (shows `AuthPage`). A saved
token is re-verified against `GET /auth/me` on load rather than trusted blindly,
so a revoked/expired token drops back to the login screen instead of showing a
stale user. The guest choice is remembered in `localStorage` too, so a guest who
reloads the page stays a guest rather than being bounced back to the login
screen. `api/client.js` attaches the token to every request automatically and
calls a registered listener on any `401` response — that's what logs the whole
app out immediately if a token expires mid-session, not just on the next manual
action.

The account chip in the nav (top-right, and inside the mobile menu) shows who's
signed in, or "Guest", and doubles as the logout button — clicking it always
calls `logout()`, which works correctly for both a real session and a guest one.

Guest mode is a genuine first-class path, not a stripped-down demo: every page
and every API call already tolerates having no `req.user` (see the backend's
`optionalAuthenticate` middleware), so a guest can browse, use the EMI
calculator, book a service, and even use the garage/health pages exactly like a
logged-in user — see the backend README's note on what garage-data ownership
does and doesn't enforce yet.

## Theming
`ThemeContext` defaults to the OS/browser color-scheme preference, then remembers
whatever the person picks via the sun/moon toggle in the nav (stored in
`localStorage`, applied as `data-theme` on `<html>` — see the CSS variable
overrides at the top of `styles/index.css`).

## Bluetooth vehicle health (`features/health/BluetoothPanel.jsx`)
Uses the real Web Bluetooth API (`navigator.bluetooth`), not a simulation. Two
honest limitations worth knowing before demoing this:
- **Browser support**: Chrome/Edge (desktop and Android) only — Safari and
  Firefox don't implement Web Bluetooth at all.
- **Hardware support**: only Bluetooth *Low Energy* devices are visible to a
  browser. Most budget ELM327 OBD-II dongles use classic Bluetooth (SPP) and
  simply won't show up in the picker — this is a browser/OS platform limit,
  not a bug in this app.

Because of that second point, there's no universal "decode any OBD dongle"
feature here — no such thing exists without picking one specific adapter
model and its proprietary protocol. What *is* real: a genuine GATT connect,
service/characteristic discovery, live `notify` subscriptions, and a raw-data
log the user can save into that vehicle's history. Manual entry is the
reliable path for any vehicle regardless of what hardware is on hand.

## Scripts
- `npm run dev` — dev server on :5173, proxies `/api` to `http://localhost:4000`
- `npm run build` — production build (verified: builds cleanly, code-split per route)
- `npm run preview` — preview the production build locally

## Config
Copy `.env.example` to `.env` and set `VITE_API_BASE_URL` if the API isn't served
from the same origin in production (dev uses the Vite proxy, so it can stay empty locally).
