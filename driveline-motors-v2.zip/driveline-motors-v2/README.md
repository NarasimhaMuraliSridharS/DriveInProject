# Driveline Motors — v2 architecture

A rebuilt version of the Driveline Motors app (vehicle browsing, EMI calculator,
service-center booking) using a proper layered architecture:

```
routes -> controllers -> services -> repositories -> database   (backend)
pages  -> hooks -> api client                                    (frontend)
```

## Why this structure

- **routes/** only wire URLs to controllers + validation. No logic.
- **controllers/** parse the request and shape the response. No SQL, no business rules.
- **services/** hold business rules — e.g. the vehicle match/ranking score, and the
  slot-capacity check that prevents double-booking a service slot.
- **repositories/** are the only files that know SQL. Swap Postgres for something
  else later and only this folder changes.
- **validators/** (Zod schemas) reject bad input before it reaches a controller.
- **middlewares/** centralize cross-cutting concerns: async error forwarding,
  request logging, and the one place that turns any thrown error into an HTTP response.

The frontend mirrors this: `features/<domain>/` folders hold each page and its
sub-components, `hooks/` own data-fetching and loading/error state, `api/` is the
only place that calls `fetch`, and routing uses real URLs (`/`, `/emi`, `/service`)
via `react-router-dom` instead of in-memory tab state.

## Run it locally

**Backend**
```bash
cd backend
cp .env.example .env      # point DATABASE_URL at your Postgres instance
npm install
npm run migrate           # creates tables
npm run seed               # loads sample vehicles
npm run dev                 # http://localhost:4000
npm test                    # runs the validator test suite
```

**Frontend**
```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173, proxies /api -> :4000
npm run build                # production build (verified working, code-split per route)
```

## v2.1 additions

- **Responsive across all screen sizes** — real mobile/tablet/desktop breakpoints,
  a collapsible hamburger nav on small screens, fluid headings, and a
  `color-scheme` meta tag so native form controls follow the theme.
- **Light / dark mode** — a toggle in the nav, defaulting to the OS preference
  and remembered in `localStorage` (`frontend/src/context/ThemeContext.jsx`).
- **My Garage** — register vehicles you actually own (separate from the dealer's
  sale inventory), track insurance expiry, RC fitness expiry, and service-due
  status (by odometer *and* by time, whichever is more urgent), with a
  notification bell in the nav showing live alert counts.
- **Vehicle health tracking** — manual reading log (battery, fuel, odometer,
  engine temp, trouble codes) plus a genuine Web Bluetooth integration for
  compatible BLE adapters, with honest in-app messaging about browser/hardware
  support rather than pretending it works with every dongle on the market.

See `backend/README.md` and `frontend/README.md` for the full breakdown of each.

## v2.2 additions

- **Real authentication** — phone number + password, bcrypt-hashed on the
  backend, JWT-based sessions. A `users` table, `/auth/register`, `/auth/login`,
  `/auth/me` on the API side; an `AuthContext` + login/register screen on the
  frontend.
- **Explore as guest** — a first-class third option alongside login/register,
  not a locked-down trial. Every existing API route already tolerates a
  request with no logged-in user (`optionalAuthenticate` middleware, applied
  globally), so a guest gets full access to browsing, the EMI calculator,
  service bookings, and the garage/health pages — remembered across a reload,
  same as a real session.
- Verified with a real headless-browser run through the actual UI (not just
  the API): register → land in app → log out → log back in → log out → guest
  mode → reload while guest → navigate as guest → log out of guest → wrong
  password shows an inline error. All nine steps passed against the live app.

## What's new vs. the original version

- Consistent API response envelope (`{ success, message, data, meta }`) and one
  central error handler, instead of routes each doing their own thing.
- Input validation (Zod) on every endpoint — bad requests get a clear 400 with
  field-level errors instead of hitting the database with bad data.
- **Overbooking prevention**: a Postgres advisory lock + transaction stops two
  people from booking the same slot past its capacity, even under concurrent load.
  This didn't exist before — the old version would happily accept unlimited
  bookings for the same slot.
- Vehicle matching/ranking logic lives in the backend only (`/vehicles/match`),
  so the frontend and backend can never compute different scores for the same
  preferences.
- Pagination on list endpoints, consistent naming (`minPrice`/`maxPrice` instead
  of a one-off `maxBudget`), and an indexed schema (`type`, `brand`, `price`,
  `date+slot`, `status`).
- Real routing (shareable/bookmarkable URLs, browser back/forward) instead of
  tab state, with code-split pages so each route only loads what it needs.
- A backend test suite (`node --test`) and a shared frontend toast system.

## Website -> all devices

This build is "website first" as requested: the layout is already responsive
(the CSS has breakpoints for mobile: filters/panels stack, tables scroll
horizontally, nav wraps, toasts adapt to narrow screens). To extend to other
devices from here:

- **Progressive Web App**: add a `manifest.json` + service worker so it can be
  "installed" on phones/desktops from the browser — no store submission needed.
- **Native apps**: wrap the same API with React Native (Expo) or Flutter,
  reusing every backend endpoint as-is since the API layer is already fully
  decoupled from the web client.
- **API stability**: because routes are versioned (`/api/v1/...`), future
  mobile clients can keep using v1 even if a v2 is introduced later for the web.
